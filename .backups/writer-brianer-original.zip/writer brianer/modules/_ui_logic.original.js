// modules/ui_logic.js

(function () {
    'use strict';

    // 确保全局命名空间存在
    window.WBAP = window.WBAP || {};
    const Logger = WBAP.Logger;

    let panelElement = null;
    let settingsElement = null;
    let tiagangElement = null;
    const tiagangWorldbookCache = new Map();
    let tiagangActiveWorldbook = null;

    function ensureProgressPanel(templates) {
        const existing = document.getElementById('wbap-progress-panel');
        if (existing) {
            const hasBar = existing.querySelector('#wbap-progress-bar');
            const hasStatus = existing.querySelector('#wbap-progress-status');
            const hasTimer = existing.querySelector('#wbap-progress-timer');
            if (hasBar && hasStatus && hasTimer) {
                return { element: existing, created: false };
            }
            const wrapper = document.createElement('div');
            wrapper.innerHTML = templates.PROGRESS_PANEL_HTML;
            const fresh = wrapper.firstElementChild;
            existing.replaceWith(fresh);
            return { element: fresh, created: true };
        }

        const wrapper = document.createElement('div');
        wrapper.innerHTML = templates.PROGRESS_PANEL_HTML;
        document.body.appendChild(wrapper.firstElementChild);
        return { element: document.getElementById('wbap-progress-panel'), created: true };
    }

    function ensureFloatButton() {
        if (document.getElementById('wbap-float-btn')) return;

        const floatBtn = document.createElement('button');
        floatBtn.id = 'wbap-float-btn';
        floatBtn.className = 'wbap-fab'; // 使用CSS类
        floatBtn.innerHTML = '<i class="fa-solid fa-cat"></i>';
        floatBtn.title = '笔者之脑';
        document.body.appendChild(floatBtn);

        const savedPosition = localStorage.getItem('wbap_float_ball_position');
        if (savedPosition) {
            try {
                const pos = JSON.parse(savedPosition);
                floatBtn.style.top = pos.top;
                floatBtn.style.left = pos.left;
            } catch (e) {
                floatBtn.style.top = '';
                floatBtn.style.left = '';
            }
        }

        const onClick = () => {
            if (panelElement) {
                document.body.classList.remove('wbap-mobile-settings-mode');
                document.documentElement.classList.remove('wbap-mobile-settings-mode');
                if (settingsElement) settingsElement.classList.remove('open');

                panelElement.classList.toggle('open');
                syncMobileRootFix();
            }
        };
        const onDragEnd = (pos) => {
            localStorage.setItem('wbap_float_ball_position', JSON.stringify(pos));
        };

        WBAP.makeDraggable(floatBtn, onClick, onDragEnd);
        Logger.log('悬浮按钮已注入');
    }

    function syncMobileRootFix() {
        try {
            const anyOverlayOpen = !!document.querySelector('.wbap-panel.open, .wbap-settings.open, .wbap-modal.open, #wbap-entry-modal.open');
            const shouldLockMobileRoot = window.innerWidth <= 900 && anyOverlayOpen;
            document.body.classList.toggle('wbap-mobile-root-fix', shouldLockMobileRoot);
            document.documentElement.classList.toggle('wbap-mobile-root-fix', shouldLockMobileRoot);
            document.body.classList.toggle('wbap-overlay-open', anyOverlayOpen);
            document.documentElement.classList.toggle('wbap-overlay-open', anyOverlayOpen);
        } catch (e) {
            // non-critical
        }
    }

    function injectUI() {
        try {
            Logger.log('开始注入 UI');

            const templates = WBAP.UI_TEMPLATES;
            if (!templates) {
                Logger.error('UI 模板不可用，无法注入。');
                return;
            }

            if (document.getElementById('wbap-panel')) {
                panelElement = document.getElementById('wbap-panel');
                settingsElement = document.getElementById('wbap-settings');
                tiagangElement = document.getElementById('wbap-tiagang-settings');
                ensureFloatButton();

                const progress = ensureProgressPanel(templates);
                bindProgressPanelEvents();

                Logger.log('UI 已存在，已补齐缺失组件');
                return;
            }

            // 注入悬浮按钮
            ensureFloatButton();

            // 注入模板
            const panelDiv = document.createElement('div');
            panelDiv.innerHTML = templates.PANEL_HTML;
            document.body.appendChild(panelDiv.firstElementChild);
            panelElement = document.getElementById('wbap-panel');

            const settingsDiv = document.createElement('div');
            settingsDiv.innerHTML = templates.SETTINGS_HTML;
            document.body.appendChild(settingsDiv.firstElementChild);
            settingsElement = document.getElementById('wbap-settings');
            const tiagangDiv = document.createElement('div');
            tiagangDiv.innerHTML = templates.TIANGANG_SETTINGS_HTML;
            document.body.appendChild(tiagangDiv.firstElementChild);
            tiagangElement = document.getElementById('wbap-tiagang-settings');
            if (settingsElement) {
                Logger.log('设置元素 #wbap-settings 已成功注入和获取。');
            } else {
                Logger.error('错误：无法获取 #wbap-settings 元素。');
            }

            const editorDiv = document.createElement('div');
            editorDiv.innerHTML = templates.PROMPT_EDITOR_HTML;
            document.body.appendChild(editorDiv.firstElementChild);

            const pickerDiv = document.createElement('div');
            pickerDiv.innerHTML = templates.PROMPT_PICKER_HTML;
            document.body.appendChild(pickerDiv.firstElementChild);

            const endpointEditorDiv = document.createElement('div');
            endpointEditorDiv.innerHTML = templates.API_ENDPOINT_EDITOR_HTML;
            document.body.appendChild(endpointEditorDiv.firstElementChild);

            ensureProgressPanel(templates);

            // 绑定事件并刷新
            bindPanelEvents();
            bindSettingsEvents();
            bindTiagangEvents();
            bindMemorySection();
            bindEditorEvents();
            bindEndpointEditorEvents();
            bindProgressPanelEvents();
            refreshPromptList();
            loadSettingsToUI();
            renderApiEndpoints();

            syncMobileRootFix();
            Logger.log('UI 注入成功');
        } catch (e) {
            Logger.error('UI 注入失败:', e);
        }
    }


    function bindPanelEvents() {
        document.getElementById('wbap-close-btn')?.addEventListener('click', () => {
            if (panelElement) panelElement.classList.remove('open');
            syncMobileRootFix();
        });

        document.getElementById('wbap-settings-btn')?.addEventListener('click', () => {
            // Close main panel when opening settings (standard behavior)
            if (panelElement) panelElement.classList.remove('open');
            if (settingsElement) settingsElement.classList.add('open');
            syncMobileRootFix();
        });

        document.getElementById('wbap-tiagang-btn')?.addEventListener('click', () => {
            if (panelElement) panelElement.classList.remove('open');
            if (settingsElement) settingsElement.classList.remove('open');
            if (tiagangElement) {
                loadTiagangSettingsToUI();
                tiagangElement.classList.add('open');
            }
            syncMobileRootFix();
        });

        document.getElementById('wbap-memory-open-btn')?.addEventListener('click', () => {
            if (WBAP.MemoryModule?.openMemoryModal) {
                WBAP.MemoryModule.openMemoryModal();
            }
        });

        // 初始化记忆状态徽章
        const memStatus = document.getElementById('wbap-memory-status');
        if (memStatus) {
            const cfg = WBAP.CharacterManager?.getCurrentCharacterConfig?.() || WBAP.config;
            const enabled = cfg?.memoryModule?.enabled === true;
            memStatus.textContent = enabled ? '已启用' : '未启用';
            memStatus.classList.toggle('wbap-badge-success', enabled);
            memStatus.classList.add('wbap-badge');
        }

        const promptSelect = document.getElementById('wbap-prompt-preset-select');
        promptSelect?.addEventListener('change', () => {
            const currentConfig = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
            const newIndex = parseInt(promptSelect.value);
            currentConfig.selectedPromptIndex = newIndex;
            // 同步更新全局 config
            if (WBAP.config !== currentConfig) {
                WBAP.config.selectedPromptIndex = newIndex;
            }
            WBAP.saveConfig();
            refreshPromptList();
        });

        document.getElementById('wbap-prompt-new-btn')?.addEventListener('click', () => window.wbapEditPrompt(-1));
        document.getElementById('wbap-prompt-edit-btn')?.addEventListener('click', () => {
            const currentConfig = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
            window.wbapEditPrompt(currentConfig.selectedPromptIndex);
        });
        document.getElementById('wbap-prompt-delete-btn')?.addEventListener('click', () => {
            const currentConfig = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
            window.wbapDeletePrompt(currentConfig.selectedPromptIndex);
        });
        document.getElementById('wbap-prompt-export-btn')?.addEventListener('click', () => exportCurrentPrompt());

        // 副提示词事件
        const secondarySelect = document.getElementById('wbap-secondary-preset-select');
        secondarySelect?.addEventListener('change', () => {
            const cfg = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
            if (!cfg.secondaryPrompt) cfg.secondaryPrompt = { enabled: false, selectedPromptIndex: 0, boundEndpointIds: [] };
            cfg.secondaryPrompt.selectedPromptIndex = parseInt(secondarySelect.value) || 0;
            if (WBAP.config !== cfg) {
                WBAP.config.secondaryPrompt = cfg.secondaryPrompt;
            }
            WBAP.saveConfig();
            refreshSecondaryPromptUI();
        });
        document.getElementById('wbap-secondary-enabled')?.addEventListener('change', (e) => {
            const cfg = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
            if (!cfg.secondaryPrompt) cfg.secondaryPrompt = { enabled: false, selectedPromptIndex: 0, boundEndpointIds: [] };
            cfg.secondaryPrompt.enabled = e.target.checked;
            if (WBAP.config !== cfg) {
                WBAP.config.secondaryPrompt = cfg.secondaryPrompt;
            }
            WBAP.saveConfig();
            refreshSecondaryPromptUI();
        });
        const secondaryBindBtn = document.getElementById('wbap-secondary-bind-btn');
        const secondaryList = document.getElementById('wbap-secondary-binding-list');
        secondaryBindBtn?.addEventListener('click', () => {
            if (!secondaryList) return;
            const hidden = secondaryList.style.display === 'none' || secondaryList.style.display === '';
            secondaryList.style.display = hidden ? 'block' : 'none';
        });
        secondaryList?.addEventListener('change', () => {
            const selected = getSecondaryBindingSelection();
            updateSecondaryBindingSummary(selected);
            const cfg = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
            if (!cfg.secondaryPrompt) cfg.secondaryPrompt = { enabled: false, selectedPromptIndex: 0, boundEndpointIds: [] };
            cfg.secondaryPrompt.boundEndpointIds = selected;
            if (WBAP.config !== cfg) {
                WBAP.config.secondaryPrompt = cfg.secondaryPrompt;
            }
            WBAP.saveConfig();
        });

        // 主提示词绑定入口（面板）
        const mainBindingBtn = document.getElementById('wbap-prompt-bind-apis-btn');
        const mainBindingList = document.getElementById('wbap-prompt-binding-list');
        if (mainBindingBtn && mainBindingList) {
            mainBindingBtn.addEventListener('click', () => {
                const hidden = mainBindingList.style.display === 'none' || mainBindingList.style.display === '';
                mainBindingList.style.display = hidden ? 'block' : 'none';
            });
            mainBindingList.addEventListener('change', () => {
                const selected = getPromptBindingSelection();
                // 更新绑定标签和摘要（不重新渲染列表，避免列表收起）
                updatePromptBindingTags(selected);
                updatePromptBindingSummary(selected);
                const cfg = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
                const prompts = WBAP.PromptManager.getCombinedPrompts();
                const currentPrompt = prompts[cfg.selectedPromptIndex || 0];
                if (currentPrompt) {
                    WBAP.PromptManager.addOrUpdatePrompt({ ...currentPrompt, boundEndpointIds: selected });
                    WBAP.saveConfig();
                    // 注意：不再调用 refreshPromptList()，避免列表自动收起
                }
            });
        }

        // 代理 API 列表点击（移动端更友好）
        document.getElementById('wbap-api-endpoint-list')?.addEventListener('click', (e) => {
            if (e.target.closest('.wbap-api-endpoint-header label')) return;
            if (e.target.closest('button, input, select, textarea, .wbap-btn')) return;
            const item = e.target.closest('.wbap-api-endpoint-item');
            if (item && item.dataset.id) {
                window.wbapEditEndpoint(item.dataset.id);
            }
        });

        document.getElementById('wbap-save-variables-btn')?.addEventListener('click', (e) => {
            WBAP.saveConfig();
            const btn = e.currentTarget;
            btn.textContent = '已应用!';
            setTimeout(() => {
                btn.textContent = '应用变量';
            }, 1500);
        });

        const importBtn = document.getElementById('wbap-import-prompt-btn');
        const fileInput = document.getElementById('wbap-prompt-file-input');
        if (importBtn && fileInput) {
            importBtn.addEventListener('click', () => fileInput.click());
            fileInput.addEventListener('change', async (e) => {
                const file = e.target.files[0];
                if (file) {
                    try {
                        const content = await file.text();
                        const prompt = JSON.parse(content);
                        const currentConfig = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
                        WBAP.PromptManager.addOrUpdatePrompt(prompt);
                        const combinedPrompts = WBAP.PromptManager.getCombinedPrompts();
                        let newIndex = combinedPrompts.findIndex(p => p.name === prompt.name);
                        if (newIndex < 0) newIndex = Math.max(0, combinedPrompts.length - 1);
                        currentConfig.selectedPromptIndex = newIndex;
                        // 同步更新全局 config
                        if (WBAP.config !== currentConfig) {
                            WBAP.config.selectedPromptIndex = currentConfig.selectedPromptIndex;
                        }
                        // 确保总局提示词索引仍在有效范围内
                        if (currentConfig.aggregatorMode) {
                            const maxIndex = Math.max(0, combinedPrompts.length - 1);
                            currentConfig.aggregatorMode.promptIndex = Math.min(currentConfig.aggregatorMode.promptIndex ?? 0, maxIndex);
                        }
                        WBAP.saveConfig();
                        refreshPromptList();
                        renderAggregatorControls();
                        Logger.log('提示词导入成功:', prompt.name);
                    } catch (err) {
                        Logger.error('导入提示词失败:', err);
                        alert('导入失败: ' + err.message);
                    }
                }
                fileInput.value = '';
            });
        }

        // 提示词选择弹窗
        const promptPickerModal = document.getElementById('wbap-prompt-picker-modal');
        const promptPickerList = document.getElementById('wbap-prompt-picker-list');
        const openPromptPicker = () => {
            if (!promptPickerModal || !promptPickerList) return;
            const prompts = WBAP.PromptManager.getCombinedPrompts();
            const currentConfig = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
            const selected = currentConfig.selectedPromptIndex || 0;
            if (!prompts.length) {
                promptPickerList.innerHTML = '<div class="wbap-empty-state"><p>暂无预设，请先新建或导入</p></div>';
            } else {
                promptPickerList.innerHTML = prompts.map((p, idx) => `
                    <label class="wbap-prompt-picker-item">
                        <input type="radio" name="wbap-prompt-picker" value="${idx}" ${idx === selected ? 'checked' : ''}>
                        <div class="wbap-prompt-picker-text">
                            <div class="title">${p.name || '未命名预设'}</div>
                            <div class="desc">${p.description || ''}</div>
                        </div>
                    </label>
                `).join('');
            }
            promptPickerModal.classList.add('open');
            syncMobileRootFix();
        };
        const closePromptPicker = () => {
            if (promptPickerModal) promptPickerModal.classList.remove('open');
            syncMobileRootFix();
        };

        document.getElementById('wbap-open-prompt-picker')?.addEventListener('click', openPromptPicker);
        document.getElementById('wbap-prompt-picker-close')?.addEventListener('click', closePromptPicker);
        document.getElementById('wbap-prompt-picker-cancel')?.addEventListener('click', closePromptPicker);
        document.getElementById('wbap-prompt-picker-apply')?.addEventListener('click', () => {
            if (!promptPickerList) return;
            const checked = promptPickerList.querySelector('input[name=\"wbap-prompt-picker\"]:checked');
            if (checked) {
                const newIndex = parseInt(checked.value);
                const currentConfig = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
                currentConfig.selectedPromptIndex = newIndex;
                if (WBAP.config !== currentConfig) {
                    WBAP.config.selectedPromptIndex = newIndex;
                }
                WBAP.saveConfig();
                refreshPromptList();
            }
            closePromptPicker();
        });
    }

    function bindSettingsEvents() {
        document.getElementById('wbap-settings-close')?.addEventListener('click', () => {
            if (settingsElement) settingsElement.classList.remove('open');
            document.body.classList.remove('wbap-mobile-settings-mode');
            document.documentElement.classList.remove('wbap-mobile-settings-mode');
            if (panelElement) panelElement.classList.add('open');
            syncMobileRootFix();
        });

        document.getElementById('wbap-add-api-btn')?.addEventListener('click', () => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            if (!config.selectiveMode.apiEndpoints) {
                config.selectiveMode.apiEndpoints = [];
            }
            config.selectiveMode.apiEndpoints.push({
                id: `ep_${Date.now()}`,
                name: `新增API-${config.selectiveMode.apiEndpoints.length + 1}`,
                apiUrl: '',
                apiKey: '',
                model: '',
                maxTokens: 2000,
                temperature: 0.7,
                topP: 1,
                presencePenalty: 0,
                frequencyPenalty: 0,
                maxRetries: 1,
                retryDelayMs: 800,
                timeout: 60,
                enabled: true,
                dedupe: true,
                worldBooks: [],
                assignedEntriesMap: {}
            });
            renderApiEndpoints();
            refreshSecondaryPromptUI();
        });

        document.getElementById('wbap-agg-enabled')?.addEventListener('change', (e) => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            if (!config.aggregatorMode) config.aggregatorMode = { enabled: false, endpointId: '', promptIndex: 0, allowDuplicate: false };
            config.aggregatorMode.enabled = e.target.checked;
        });
        document.getElementById('wbap-agg-endpoint')?.addEventListener('change', (e) => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            if (!config.aggregatorMode) config.aggregatorMode = { enabled: false, endpointId: '', promptIndex: 0, allowDuplicate: false };
            config.aggregatorMode.endpointId = e.target.value;
        });
        document.getElementById('wbap-agg-prompt')?.addEventListener('change', (e) => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            if (!config.aggregatorMode) config.aggregatorMode = { enabled: false, endpointId: '', promptIndex: 0, allowDuplicate: false };
            config.aggregatorMode.promptIndex = parseInt(e.target.value, 10) || 0;
        });
        document.getElementById('wbap-agg-allow-duplicate')?.addEventListener('change', (e) => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            if (!config.aggregatorMode) config.aggregatorMode = { enabled: false, endpointId: '', promptIndex: 0, allowDuplicate: false };
            config.aggregatorMode.allowDuplicate = e.target.checked === true;
        });

        const superEnabledEl = document.getElementById('wbap-super-concurrency');
        superEnabledEl?.addEventListener('change', (e) => {
            const globalSettings = WBAP.mainConfig.globalSettings || {};
            globalSettings.enableSuperConcurrency = e.target.checked === true;
            WBAP.mainConfig.globalSettings = globalSettings;
            toggleSuperConcurrencySection(globalSettings.enableSuperConcurrency === true);
        });
        const superModeEl = document.getElementById('wbap-super-concurrency-mode');
        superModeEl?.addEventListener('change', (e) => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            const superCfg = ensureSuperConcurrencyConfig(config);
            superCfg.mode = e.target.value || 'basic';
            toggleSuperConcurrencyMode(superCfg.mode);
        });
        const superRoundsEl = document.getElementById('wbap-super-concurrency-rounds');
        superRoundsEl?.addEventListener('change', (e) => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            const superCfg = ensureSuperConcurrencyConfig(config);
            const value = parseInt(e.target.value, 10);
            superCfg.reviewRounds = Number.isFinite(value) && value > 0 ? value : 1;
        });
        const superShowPanelEl = document.getElementById('wbap-super-concurrency-show-panel');
        superShowPanelEl?.addEventListener('change', (e) => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            const superCfg = ensureSuperConcurrencyConfig(config);
            superCfg.showPanel = e.target.checked === true;
            if (!superCfg.showPanel) {
                WBAP.CabinetUI?.close?.();
            }
        });
        document.getElementById('wbap-open-cabinet-panel')?.addEventListener('click', () => {
            WBAP.CabinetUI?.open?.();
        });
        const cabinetPromptSelect = document.getElementById('wbap-cabinet-prompt-select');
        cabinetPromptSelect?.addEventListener('change', (e) => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            const superCfg = ensureSuperConcurrencyConfig(config);
            superCfg.selectedPromptIndex = parseInt(e.target.value, 10) || 0;
            WBAP.saveConfig();
            refreshCabinetPromptList();
        });
        document.getElementById('wbap-cabinet-prompt-new-btn')?.addEventListener('click', () => openCabinetPromptEditor(-1));
        document.getElementById('wbap-cabinet-prompt-edit-btn')?.addEventListener('click', () => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            const superCfg = ensureSuperConcurrencyConfig(config);
            openCabinetPromptEditor(superCfg.selectedPromptIndex || 0);
        });
        document.getElementById('wbap-cabinet-prompt-delete-btn')?.addEventListener('click', () => deleteCabinetPrompt());
        document.getElementById('wbap-cabinet-prompt-export-btn')?.addEventListener('click', () => exportCabinetPrompt());
        const cabinetImportBtn = document.getElementById('wbap-cabinet-prompt-import-btn');
        const cabinetFileInput = document.getElementById('wbap-cabinet-prompt-file-input');
        if (cabinetImportBtn && cabinetFileInput) {
            cabinetImportBtn.addEventListener('click', () => cabinetFileInput.click());
            cabinetFileInput.addEventListener('change', async (e) => {
                const file = e.target.files[0];
                if (file) {
                    try {
                        const content = await file.text();
                        const prompt = JSON.parse(content);
                        importCabinetPrompt(prompt);
                    } catch (err) {
                        Logger.error('导入内阁提示词失败:', err);
                        alert('导入失败: ' + err.message);
                    } finally {
                        cabinetFileInput.value = '';
                    }
                }
            });
        }
        document.getElementById('wbap-cabinet-save-variables-btn')?.addEventListener('click', (e) => {
            WBAP.saveConfig();
            const btn = e.currentTarget;
            btn.textContent = '已应用';
            setTimeout(() => {
                btn.textContent = '应用变量';
            }, 1500);
        });

        const optimizationCheckbox = document.getElementById('wbap-settings-plot-optimization');
        optimizationCheckbox?.addEventListener('change', (e) => {
            setOptimizationSectionState(e.target.checked === true);
        });

        // 三级优化开关
        document.getElementById('wbap-settings-level3-enabled')?.addEventListener('change', (e) => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            const level3Cfg = ensureOptimizationPromptConfig(config);
            level3Cfg.enabled = e.target.checked;
        });

        const optPromptSelect = document.getElementById('wbap-opt-prompt-select');
        optPromptSelect?.addEventListener('change', (e) => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            const level3Cfg = ensureOptimizationPromptConfig(config);
            const idx = parseInt(e.target.value, 10) || 0;
            level3Cfg.selectedPromptIndex = idx;
            const preset = level3Cfg.promptPresets?.[idx];
            if (preset) {
                level3Cfg.systemPrompt = preset.systemPrompt || '';
                level3Cfg.promptTemplate = preset.promptTemplate || '';
                config.optimizationSystemPrompt = preset.systemPrompt || '';
            }
            WBAP.saveConfig();
            refreshOptimizationPromptList();
        });

        document.getElementById('wbap-opt-prompt-new-btn')?.addEventListener('click', () => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            const level3Cfg = ensureOptimizationPromptConfig(config);
            const basePreset = WBAP.Optimization?.getDefaultOptimizationPromptPreset?.() || {
                name: '优化提示词',
                description: '',
                systemPrompt: WBAP.DEFAULT_OPT_SYSTEM_PROMPT || '',
                promptTemplate: WBAP.DEFAULT_OPT_PROMPT_TEMPLATE || ''
            };
            const nextIndex = level3Cfg.promptPresets.length + 1;
            const newPreset = {
                ...basePreset,
                name: `${basePreset.name || '优化提示词'} ${nextIndex}`
            };
            level3Cfg.promptPresets.push(newPreset);
            level3Cfg.selectedPromptIndex = level3Cfg.promptPresets.length - 1;
            level3Cfg.systemPrompt = newPreset.systemPrompt || '';
            level3Cfg.promptTemplate = newPreset.promptTemplate || '';
            config.optimizationSystemPrompt = newPreset.systemPrompt || '';
            WBAP.saveConfig();
            refreshOptimizationPromptList();
            WBAP.Optimization?.openLevel3Editor?.();
        });

        document.getElementById('wbap-opt-prompt-edit-btn')?.addEventListener('click', () => {
            WBAP.Optimization?.openLevel3Editor?.();
        });

        document.getElementById('wbap-opt-prompt-delete-btn')?.addEventListener('click', () => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            const level3Cfg = ensureOptimizationPromptConfig(config);
            const presets = level3Cfg.promptPresets || [];
            if (presets.length <= 1) {
                alert('至少保留一个提示词预设');
                return;
            }
            const idx = level3Cfg.selectedPromptIndex || 0;
            const target = presets[idx];
            if (!confirm(`确定删除预设「${target?.name || '未命名'}」？`)) return;
            presets.splice(idx, 1);
            level3Cfg.selectedPromptIndex = Math.max(0, Math.min(idx, presets.length - 1));
            const nextPreset = presets[level3Cfg.selectedPromptIndex];
            if (nextPreset) {
                level3Cfg.systemPrompt = nextPreset.systemPrompt || '';
                level3Cfg.promptTemplate = nextPreset.promptTemplate || '';
                config.optimizationSystemPrompt = nextPreset.systemPrompt || '';
            }
            WBAP.saveConfig();
            refreshOptimizationPromptList();
        });

        const optPromptImportBtn = document.getElementById('wbap-opt-prompt-import-btn');
        const optPromptFileInput = document.getElementById('wbap-opt-prompt-file-input');
        if (optPromptImportBtn && optPromptFileInput) {
            optPromptImportBtn.addEventListener('click', () => optPromptFileInput.click());
            optPromptFileInput.addEventListener('change', async (e) => {
                const file = e.target.files[0];
                if (!file) return;
                try {
                    const content = await file.text();
                    const parsed = JSON.parse(content);
                    const preset = {
                        name: parsed.name || '导入提示词',
                        description: parsed.description || '',
                        systemPrompt: parsed.systemPrompt || '',
                        promptTemplate: parsed.promptTemplate || ''
                    };
                    if (!preset.systemPrompt && !preset.promptTemplate) {
                        throw new Error('提示词内容为空');
                    }
                    const config = WBAP.CharacterManager.getCurrentCharacterConfig();
                    const level3Cfg = ensureOptimizationPromptConfig(config);
                    level3Cfg.promptPresets.push(preset);
                    level3Cfg.selectedPromptIndex = level3Cfg.promptPresets.length - 1;
                    level3Cfg.systemPrompt = preset.systemPrompt || '';
                    level3Cfg.promptTemplate = preset.promptTemplate || '';
                    config.optimizationSystemPrompt = preset.systemPrompt || '';
                    WBAP.saveConfig();
                    refreshOptimizationPromptList();
                } catch (err) {
                    Logger.error('导入剧情优化提示词失败:', err);
                    alert('导入失败: ' + err.message);
                } finally {
                    optPromptFileInput.value = '';
                }
            });
        }

        document.getElementById('wbap-opt-prompt-export-btn')?.addEventListener('click', () => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            const level3Cfg = ensureOptimizationPromptConfig(config);
            const presets = level3Cfg.promptPresets || [];
            const idx = level3Cfg.selectedPromptIndex || 0;
            const preset = presets[idx];
            if (!preset) return;
            const safeName = (preset.name || 'optimization_prompt').replace(/[\\/:*?"<>|]/g, '_');
            const dataStr = JSON.stringify(preset, null, 2);
            const blob = new Blob([dataStr], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${safeName}.json`;
            a.click();
            URL.revokeObjectURL(url);
        });

        document.getElementById('wbap-optimization-use-independent')?.addEventListener('change', (e) => {
            toggleOptimizationApiBlocks(e.target.checked === true);
        });

        document.getElementById('wbap-optimization-fetch-models')?.addEventListener('click', async (e) => {
            const btn = e.currentTarget;
            btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';
            btn.disabled = true;

            const tempConfig = {
                apiUrl: document.getElementById('wbap-optimization-api-url')?.value || '',
                apiKey: document.getElementById('wbap-optimization-api-key')?.value || ''
            };
            const currentModel = document.getElementById('wbap-optimization-model')?.value || '';
            const result = await WBAP.fetchEndpointModels(tempConfig);
            if (result.success) {
                populateOptimizationModelSelect(result.models, currentModel);
            } else {
                alert(`获取模型失败: ${result.message}`);
            }

            btn.innerHTML = '获取模型';
            btn.disabled = false;
        });

        document.getElementById('wbap-save-settings')?.addEventListener('click', () => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();

            config.enabled = document.getElementById('wbap-enabled').checked;
            const contextRoundsVal = parseInt(document.getElementById('wbap-context-rounds').value, 10);
            config.contextRounds = Number.isFinite(contextRoundsVal) ? contextRoundsVal : 5;

            config.enableChunking = document.getElementById('wbap-enable-chunking').checked;
            config.skipProcessedMessages = document.getElementById('wbap-skip-processed').checked;
            const tagNameInput = document.getElementById('wbap-tag-extraction-name');
            config.tagExtractionName = (tagNameInput?.value || '').trim();
            const mergeWorldbooksEl = document.getElementById('wbap-merge-worldbooks');
            const useSelectedWorldbooksEl = document.getElementById('wbap-use-selected-worldbooks');
            if (mergeWorldbooksEl) config.mergeWorldBooks = mergeWorldbooksEl.checked === true;
            if (useSelectedWorldbooksEl) config.useSelectedWorldBooks = useSelectedWorldbooksEl.checked === true;
            if (!config.aggregatorMode) {
                config.aggregatorMode = { enabled: false, endpointId: '', promptIndex: 0, allowDuplicate: false };
            }
            const aggEnabledEl = document.getElementById('wbap-agg-enabled');
            const aggEndpointEl = document.getElementById('wbap-agg-endpoint');
            const aggPromptEl = document.getElementById('wbap-agg-prompt');
            const aggAllowDuplicateEl = document.getElementById('wbap-agg-allow-duplicate');
            if (aggEnabledEl) config.aggregatorMode.enabled = aggEnabledEl.checked;
            if (aggEndpointEl) config.aggregatorMode.endpointId = aggEndpointEl.value;
            if (aggPromptEl) config.aggregatorMode.promptIndex = parseInt(aggPromptEl.value, 10) || 0;
            if (aggAllowDuplicateEl) config.aggregatorMode.allowDuplicate = aggAllowDuplicateEl.checked === true;



            // 全局设置
            const globalSettings = WBAP.mainConfig.globalSettings || {};
            globalSettings.maxConcurrent = parseInt(document.getElementById('wbap-global-max-concurrent')?.value) || 0;
            globalSettings.timeout = parseInt(document.getElementById('wbap-global-timeout')?.value) || 0;
            globalSettings.enableSuperConcurrency = document.getElementById('wbap-super-concurrency')?.checked === true;
            WBAP.mainConfig.globalSettings = globalSettings;

            config.showProgressPanel = document.getElementById('wbap-settings-progress-panel')?.checked !== false;
            config.enablePlotOptimization = document.getElementById('wbap-settings-plot-optimization')?.checked === true;
            config.enablePlotOptimizationFloatButton = document.getElementById('wbap-settings-plot-optimization-fab')?.checked === true;
            const optimizationApiConfig = ensureOptimizationApiConfig(config);
            optimizationApiConfig.useIndependentProfile = document.getElementById('wbap-optimization-use-independent')?.checked === true;
            optimizationApiConfig.selectedEndpointId = document.getElementById('wbap-optimization-endpoint-select')?.value || null;
            optimizationApiConfig.apiUrl = document.getElementById('wbap-optimization-api-url')?.value || '';
            optimizationApiConfig.apiKey = document.getElementById('wbap-optimization-api-key')?.value || '';
            optimizationApiConfig.model = document.getElementById('wbap-optimization-model')?.value || '';
            const optMaxTokens = parseInt(document.getElementById('wbap-optimization-max-tokens')?.value, 10);
            optimizationApiConfig.maxTokens = Number.isFinite(optMaxTokens) && optMaxTokens > 0 ? optMaxTokens : 4000;
            const optTemp = parseFloat(document.getElementById('wbap-optimization-temperature')?.value);
            optimizationApiConfig.temperature = Number.isFinite(optTemp) ? optTemp : 0.7;
            const optTimeout = parseInt(document.getElementById('wbap-optimization-timeout')?.value, 10);
            optimizationApiConfig.timeout = Number.isFinite(optTimeout) && optTimeout > 0 ? optTimeout : 60;
            const optRetries = parseInt(document.getElementById('wbap-optimization-max-retries')?.value, 10);
            optimizationApiConfig.maxRetries = Number.isFinite(optRetries) && optRetries >= 0 ? optRetries : 2;
            const optRetryDelay = parseInt(document.getElementById('wbap-optimization-retry-delay')?.value, 10);
            optimizationApiConfig.retryDelayMs = Number.isFinite(optRetryDelay) && optRetryDelay > 0 ? optRetryDelay : 800;
            optimizationApiConfig.enableStreaming = document.getElementById('wbap-optimization-streaming')?.checked !== false;

            const superCfg = ensureSuperConcurrencyConfig(config);
            superCfg.mode = document.getElementById('wbap-super-concurrency-mode')?.value || 'basic';
            const reviewRounds = parseInt(document.getElementById('wbap-super-concurrency-rounds')?.value, 10);
            superCfg.reviewRounds = Number.isFinite(reviewRounds) && reviewRounds > 0 ? reviewRounds : 1;
            superCfg.showPanel = document.getElementById('wbap-super-concurrency-show-panel')?.checked !== false;

            WBAP.saveConfig();
            if (WBAP.Optimization && WBAP.Optimization.updateFloatingButtonVisibility) {
                WBAP.Optimization.updateFloatingButtonVisibility();
            }
            if (optimizationApiConfig.useIndependentProfile && optimizationApiConfig.apiUrl && WBAP.setupPreconnect) {
                WBAP.setupPreconnect([{ apiUrl: optimizationApiConfig.apiUrl }]);
            }
            if (settingsElement) settingsElement.classList.remove('open');
            if (panelElement) panelElement.classList.add('open');
            syncMobileRootFix();
            Logger.log('设置已保存到当前角色', config);
        });

        document.getElementById('wbap-export-config')?.addEventListener('click', () => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            const dataStr = JSON.stringify(config, null, 2);
            const blob = new Blob([dataStr], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'worldbook_ai_processor_char_config.json';
            a.click();
            URL.revokeObjectURL(url);
        });

        const importBtn = document.getElementById('wbap-import-config');
        const fileInput = document.getElementById('wbap-config-file-input');
        importBtn?.addEventListener('click', () => fileInput.click());
        fileInput?.addEventListener('change', async (e) => {
            const file = e.target.files[0];
            if (file) {
                try {
                    const content = await file.text();
                    const importedConf = JSON.parse(content);
                    const currentConfig = WBAP.CharacterManager.getCurrentCharacterConfig();
                    const defaultConf = WBAP.createDefaultCharacterConfig ? WBAP.createDefaultCharacterConfig() : WBAP.DEFAULT_CONFIG;

                    // 清空当前配置并用导入的配置进行深度合并
                    Object.keys(currentConfig).forEach(key => delete currentConfig[key]);
                    Object.assign(currentConfig, {
                        ...defaultConf,
                        ...importedConf,
                        selectiveMode: {
                            ...defaultConf.selectiveMode,
                            ...(importedConf.selectiveMode || {})
                        },
                    });
                    // 兼容旧字段 url/key -> apiUrl/apiKey
                    (currentConfig.selectiveMode.apiEndpoints || []).forEach(ep => {
                        normalizeEndpointStructure(ep);
                        if (ep.timeout == null) ep.timeout = 60;
                    });

                    WBAP.saveConfig();
                    loadSettingsToUI();
                    refreshPromptList();
                    Logger.log('配置已成功导入到当前角色');
                } catch (err) {
                    Logger.error('导入配置失败:', err);
                    alert('导入失败: ' + err.message);
                }
            }
            fileInput.value = '';
        });

        document.getElementById('wbap-context-rounds')?.addEventListener('input', (e) => {
            const valueEl = document.getElementById('wbap-context-rounds-value');
            if (valueEl) valueEl.textContent = e.target.value;
        });

        document.getElementById('wbap-reset-config')?.addEventListener('click', () => {
            if (confirm('确定要重置当前角色的所有配置吗？')) {
                const config = WBAP.CharacterManager.getCurrentCharacterConfig();
                // 清空并恢复默认值
                Object.keys(config).forEach(key => delete config[key]);
                const defaultConf = WBAP.createDefaultCharacterConfig ? WBAP.createDefaultCharacterConfig() : WBAP.DEFAULT_CONFIG;
                Object.assign(config, JSON.parse(JSON.stringify(defaultConf)));

                WBAP.saveConfig();
                loadSettingsToUI();
                refreshPromptList();
                Logger.log('当前角色的配置已重置');
            }
        });
    }

    function bindTiagangEvents() {
        document.getElementById('wbap-tiagang-close')?.addEventListener('click', () => {
            if (tiagangElement) tiagangElement.classList.remove('open');
            syncMobileRootFix();
        });

        const promptSelect = document.getElementById('wbap-tiagang-prompt-select');
        promptSelect?.addEventListener('change', (e) => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            const tgCfg = ensureTiagangConfig(config);
            tgCfg.selectedPromptIndex = parseInt(e.target.value, 10) || 0;
            WBAP.saveConfig();
            refreshTiagangPromptList();
        });

        document.getElementById('wbap-tiagang-prompt-new-btn')?.addEventListener('click', () => openTiagangPromptEditor(-1));
        document.getElementById('wbap-tiagang-prompt-edit-btn')?.addEventListener('click', () => {
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            const tgCfg = ensureTiagangConfig(config);
            openTiagangPromptEditor(tgCfg.selectedPromptIndex || 0);
        });
        document.getElementById('wbap-tiagang-prompt-delete-btn')?.addEventListener('click', () => deleteTiagangPrompt());
        document.getElementById('wbap-tiagang-prompt-export-btn')?.addEventListener('click', () => exportTiagangPrompt());

        const importBtn = document.getElementById('wbap-tiagang-prompt-import-btn');
        const fileInput = document.getElementById('wbap-tiagang-prompt-file-input');
        if (importBtn && fileInput) {
            importBtn.addEventListener('click', () => fileInput.click());
            fileInput.addEventListener('change', async (e) => {
                const file = e.target.files[0];
                if (file) {
                    try {
                        const content = await file.text();
                        const prompt = JSON.parse(content);
                        importTiagangPrompt(prompt);
                    } catch (err) {
                        Logger.error('Import tiangang prompt failed', err);
                        alert('\u5bfc\u5165\u5931\u8d25: ' + (err.message || err));
                    } finally {
                        fileInput.value = '';
                    }
                }
            });
        }

        document.getElementById('wbap-tiagang-save-variables-btn')?.addEventListener('click', (e) => {
            WBAP.saveConfig();
            const btn = e.currentTarget;
            btn.textContent = '\u5df2\u5e94\u7528';
            setTimeout(() => {
                btn.textContent = '\u5e94\u7528\u53d8\u91cf';
            }, 1500);
        });

        document.getElementById('wbap-tiagang-save')?.addEventListener('click', () => saveTiagangSettings());

        document.getElementById('wbap-tiagang-context-rounds')?.addEventListener('input', (e) => {
            const valueEl = document.getElementById('wbap-tiagang-context-rounds-value');
            if (valueEl) valueEl.textContent = e.target.value;
        });

        document.getElementById('wbap-tiagang-fetch-models')?.addEventListener('click', async (e) => {
            const btn = e.currentTarget;
            if (btn) {
                btn.disabled = true;
                btn.textContent = '\u83b7\u53d6\u4e2d...';
            }
            try {
                const apiUrl = document.getElementById('wbap-tiagang-api-url')?.value || '';
                const apiKey = document.getElementById('wbap-tiagang-api-key')?.value || '';
                if (!apiUrl) throw new Error('\u8bf7\u5148\u914d\u7f6e API URL');
                const result = await WBAP.fetchEndpointModels({ apiUrl, apiKey });
                if (result.success) {
                    populateTiagangModelSelect(result.models || [], document.getElementById('wbap-tiagang-model')?.value || '');
                } else {
                    throw new Error(result.message || '\u83b7\u53d6\u6a21\u578b\u5931\u8d25');
                }
            } catch (err) {
                Logger.warn('Fetch tiangang models failed', err);
                alert(`\u83b7\u53d6\u6a21\u578b\u5931\u8d25\uff1a${err.message || err}`);
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.textContent = '\u83b7\u53d6\u6a21\u578b';
                }
            }
        });

        document.getElementById('wbap-tiagang-worldbook-add')?.addEventListener('click', () => {
            const select = document.getElementById('wbap-tiagang-worldbook-select');
            const name = select?.value || '';
            if (!name) return;
            addTiagangWorldbook(name);
        });

        document.getElementById('wbap-tiagang-selected-worldbooks')?.addEventListener('click', (e) => {
            const btn = e.target.closest('[data-remove-book]');
            if (!btn) return;
            removeTiagangWorldbook(btn.dataset.removeBook);
        });

        document.getElementById('wbap-tiagang-book-list-container')?.addEventListener('click', (e) => {
            const item = e.target.closest('.wbap-book-item');
            if (!item) return;
            tiagangActiveWorldbook = item.dataset.bookName;
            const config = WBAP.CharacterManager.getCurrentCharacterConfig();
            const tgCfg = ensureTiagangConfig(config);
            renderTiagangWorldbookList(tgCfg);
            renderTiagangEntryList(tiagangActiveWorldbook);
        });

        document.getElementById('wbap-tiagang-entries-select-all')?.addEventListener('click', () => setTiagangEntrySelection(true));
        document.getElementById('wbap-tiagang-entries-clear')?.addEventListener('click', () => setTiagangEntrySelection(false));
    }

    function ensureOptimizationApiConfig(config) {
        if (!config.optimizationApiConfig) {
            config.optimizationApiConfig = {
                useIndependentProfile: false,
                selectedEndpointId: null,
                apiUrl: '',
                apiKey: '',
                model: '',
                maxTokens: 4000,
                temperature: 0.7,
                timeout: 60,
                maxRetries: 2,
                retryDelayMs: 800,
                enableStreaming: true
            };
        }
        return config.optimizationApiConfig;
    }

    function ensureOptimizationPromptConfig(config) {
        if (!config.optimizationLevel3) {
            config.optimizationLevel3 = { enabled: false, promptTemplate: '', systemPrompt: '', autoConfirm: false };
        }
        if (!Array.isArray(config.optimizationLevel3.promptPresets) || config.optimizationLevel3.promptPresets.length === 0) {
            const fallbackPreset = WBAP.Optimization?.getDefaultOptimizationPromptPreset?.() || {
                name: '默认优化提示词',
                description: '保持人设与世界观一致的剧情润色',
                systemPrompt: WBAP.DEFAULT_OPT_SYSTEM_PROMPT || '',
                promptTemplate: WBAP.DEFAULT_OPT_PROMPT_TEMPLATE || ''
            };
            config.optimizationLevel3.promptPresets = [fallbackPreset];
            config.optimizationLevel3.selectedPromptIndex = 0;
        }
        if (config.optimizationLevel3.selectedPromptIndex == null) {
            config.optimizationLevel3.selectedPromptIndex = 0;
        }
        return config.optimizationLevel3;
    }

    function ensureSuperConcurrencyConfig(config) {
        if (WBAP.ensureSuperConcurrencyConfig) {
            return WBAP.ensureSuperConcurrencyConfig(config);
        }
        if (!config.superConcurrency) {
            config.superConcurrency = {
                mode: 'basic',
                reviewRounds: 1,
                showPanel: true,
                prompts: [WBAP.createDefaultCabinetPromptPreset ? WBAP.createDefaultCabinetPromptPreset() : {}],
                selectedPromptIndex: 0
            };
        }
        return config.superConcurrency;
    }

    function ensureTiagangConfig(config) {
        if (!config.tiangang) {
            const fallbackPreset = WBAP.createDefaultTiangangPromptPreset
                ? WBAP.createDefaultTiangangPromptPreset()
                : {
                    name: 'Tiangang Prompt',
                    description: 'Plot guidance prompt',
                    systemPrompt: '',
                    mainPrompt: '',
                    finalSystemDirective: '',
                    variables: { sulv1: '', sulv2: '', sulv3: '', sulv4: '' }
                };
            config.tiangang = {
                enabled: false,
                prompts: [fallbackPreset],
                selectedPromptIndex: 0,
                contextRounds: config.contextRounds ?? 5,
                apiConfig: {
                    apiUrl: '',
                    apiKey: '',
                    model: '',
                    maxTokens: 2000,
                    temperature: 0.7,
                    timeout: 60,
                    maxRetries: 1,
                    retryDelayMs: 800
                },
                worldBooks: [],
                assignedEntriesMap: {}
            };
        }
        const tgCfg = config.tiangang;
        if (!Array.isArray(tgCfg.prompts) || tgCfg.prompts.length === 0) {
            tgCfg.prompts = [WBAP.createDefaultTiangangPromptPreset ? WBAP.createDefaultTiangangPromptPreset() : {}];
            tgCfg.selectedPromptIndex = 0;
        }
        if (tgCfg.selectedPromptIndex == null) tgCfg.selectedPromptIndex = 0;
        if (!tgCfg.apiConfig) {
            tgCfg.apiConfig = {
                apiUrl: '',
                apiKey: '',
                model: '',
                maxTokens: 2000,
                temperature: 0.7,
                timeout: 60,
                maxRetries: 1,
                retryDelayMs: 800
            };
        }
        if (!Array.isArray(tgCfg.worldBooks)) tgCfg.worldBooks = [];
        if (!tgCfg.assignedEntriesMap) tgCfg.assignedEntriesMap = {};
        if (tgCfg.contextRounds == null) tgCfg.contextRounds = config.contextRounds ?? 5;
        return tgCfg;
    }

    function toggleSuperConcurrencySection(enabled) {
        const body = document.getElementById('wbap-super-concurrency-body');
        if (body) body.classList.toggle('wbap-hidden', !enabled);
    }

    function toggleSuperConcurrencyMode(mode) {
        const roundsRow = document.getElementById('wbap-super-concurrency-rounds-row');
        if (!roundsRow) return;
        roundsRow.classList.toggle('wbap-hidden', mode !== 'advanced');
    }

    function refreshCabinetPromptList() {
        const config = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
        if (!config) return;
        const superCfg = ensureSuperConcurrencyConfig(config);
        const prompts = Array.isArray(superCfg.prompts) ? superCfg.prompts : [];
        const selectEl = document.getElementById('wbap-cabinet-prompt-select');
        const descriptionEl = document.getElementById('wbap-cabinet-prompt-description');
        if (!selectEl || !descriptionEl) return;

        if (prompts.length === 0) {
            selectEl.innerHTML = '<option value="0">无提示词</option>';
            descriptionEl.textContent = '请新建或导入一个内阁提示词。';
            refreshCabinetPromptVariables();
            return;
        }

        let idx = superCfg.selectedPromptIndex ?? 0;
        if (idx < 0 || idx >= prompts.length) {
            idx = Math.max(0, prompts.length - 1);
            superCfg.selectedPromptIndex = idx;
            WBAP.saveConfig();
        }

        selectEl.innerHTML = prompts.map((p, index) => `<option value="${index}">${p.name || `未命名预设${index + 1}`}</option>`).join('');
        selectEl.value = idx;
        descriptionEl.textContent = prompts[idx]?.description || '此预设没有描述。';
        refreshCabinetPromptVariables();
    }

    function refreshCabinetPromptVariables() {
        const container = document.getElementById('wbap-cabinet-variables-container');
        if (!container) return;
        container.innerHTML = '';

        const config = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
        if (!config) return;
        const superCfg = ensureSuperConcurrencyConfig(config);
        const prompts = Array.isArray(superCfg.prompts) ? superCfg.prompts : [];
        const idx = superCfg.selectedPromptIndex ?? 0;
        const prompt = prompts[idx];
        if (!prompt) return;

        const variables = prompt.variables || {};
        const updateVariable = (key, value) => {
            const latest = superCfg.prompts?.[idx];
            if (!latest) return;
            latest.variables = { ...(latest.variables || {}), [key]: value };
            WBAP.saveConfig();
            Logger.log(`内阁变量 ${key} 已保存: ${value}`);
        };

        for (let i = 1; i <= 4; i++) {
            const key = `sulv${i}`;
            const value = variables[key] || '';
            const item = document.createElement('div');
            item.className = 'wbap-variable-item';
            item.innerHTML = `<label for="wbap-cabinet-var-${key}">${key}</label><input type="text" id="wbap-cabinet-var-${key}" value="${value}" placeholder="变量 ${key} 的值">`;
            const inputEl = item.querySelector('input');
            inputEl.addEventListener('input', (e) => updateVariable(key, e.target.value));
            container.appendChild(item);
        }
    }

    function refreshTiagangPromptList() {
        const config = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
        if (!config) return;
        const tgCfg = ensureTiagangConfig(config);
        const prompts = Array.isArray(tgCfg.prompts) ? tgCfg.prompts : [];
        const selectEl = document.getElementById('wbap-tiagang-prompt-select');
        const descriptionEl = document.getElementById('wbap-tiagang-prompt-description');
        if (!selectEl || !descriptionEl) return;

        if (prompts.length === 0) {
            selectEl.innerHTML = '<option value="0">\u65e0\u63d0\u793a\u8bcd</option>';
            descriptionEl.textContent = '\u8bf7\u65b0\u5efa\u6216\u5bfc\u5165\u4e00\u4e2a\u5929\u7eb2\u63d0\u793a\u8bcd\u3002';
            refreshTiagangPromptVariables();
            return;
        }

        let idx = tgCfg.selectedPromptIndex ?? 0;
        if (idx < 0 || idx >= prompts.length) {
            idx = Math.max(0, prompts.length - 1);
            tgCfg.selectedPromptIndex = idx;
            WBAP.saveConfig();
        }

        selectEl.innerHTML = prompts.map((p, index) => `<option value="${index}">${p.name || `\u672a\u547d\u540d\u9884\u8bbe ${index + 1}`}</option>`).join('');
        selectEl.value = idx;
        descriptionEl.textContent = prompts[idx]?.description || '\u6b64\u9884\u8bbe\u6ca1\u6709\u63cf\u8ff0\u3002';
        refreshTiagangPromptVariables();
    }

    function refreshTiagangPromptVariables() {
        const container = document.getElementById('wbap-tiagang-variables-container');
        if (!container) return;
        container.innerHTML = '';

        const config = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
        if (!config) return;
        const tgCfg = ensureTiagangConfig(config);
        const prompts = Array.isArray(tgCfg.prompts) ? tgCfg.prompts : [];
        const idx = tgCfg.selectedPromptIndex ?? 0;
        const prompt = prompts[idx];
        if (!prompt) return;

        const variables = prompt.variables || {};
        const updateVariable = (key, value) => {
            const latest = tgCfg.prompts?.[idx];
            if (!latest) return;
            latest.variables = { ...(latest.variables || {}), [key]: value };
            WBAP.saveConfig();
        };

        for (let i = 1; i <= 4; i++) {
            const key = `sulv${i}`;
            const value = variables[key] || '';
            const item = document.createElement('div');
            item.className = 'wbap-variable-item';
            item.innerHTML = `<label for="wbap-tiagang-var-${key}">${key}</label><input type="text" id="wbap-tiagang-var-${key}" value="${value}" placeholder="\u53d8\u91cf ${key} \u7684\u503c">`;
            const inputEl = item.querySelector('input');
            inputEl.addEventListener('input', (e) => updateVariable(key, e.target.value));
            container.appendChild(item);
        }
    }

    function toggleOptimizationApiBlocks(useIndependent) {
        const independentBlock = document.getElementById('wbap-optimization-independent-block');
        const endpointBlock = document.getElementById('wbap-optimization-endpoint-block');
        if (independentBlock) independentBlock.classList.toggle('wbap-hidden', !useIndependent);
        if (endpointBlock) endpointBlock.classList.toggle('wbap-hidden', useIndependent);
    }

    function setOptimizationSectionState(enabled) {
        const section = document.getElementById('wbap-optimization-section');
        const content = document.getElementById('wbap-optimization-content');
        if (section) section.classList.toggle('expanded', !!enabled);
        if (content) {
            content.classList.toggle('wbap-hidden', !enabled);
            content.classList.toggle('wbap-disabled', !enabled);
        }
    }

    function renderOptimizationEndpointOptions(selectedId = null) {
        const selectEl = document.getElementById('wbap-optimization-endpoint-select');
        if (!selectEl) return;
        const config = WBAP.CharacterManager.getCurrentCharacterConfig();
        const endpoints = config?.selectiveMode?.apiEndpoints || [];
        const enabledEndpoints = endpoints.filter(ep => ep && ep.enabled !== false);

        selectEl.innerHTML = '';
        if (enabledEndpoints.length === 0) {
            const opt = document.createElement('option');
            opt.value = '';
            opt.textContent = '暂无可用 API';
            selectEl.appendChild(opt);
            selectEl.disabled = true;
            return;
        }

        enabledEndpoints.forEach(ep => {
            const opt = document.createElement('option');
            opt.value = ep.id;
            const modelLabel = ep.model ? ` (${ep.model})` : '';
            opt.textContent = `${ep.name}${modelLabel}`;
            selectEl.appendChild(opt);
        });
        selectEl.disabled = false;
        if (selectedId && enabledEndpoints.some(ep => ep.id === selectedId)) {
            selectEl.value = selectedId;
        } else {
            selectEl.selectedIndex = 0;
        }
    }

    function populateOptimizationModelSelect(models = [], currentModel = '') {
        const modelSelect = document.getElementById('wbap-optimization-model');
        if (!modelSelect) return;
        const list = Array.isArray(models) ? models : [];
        modelSelect.innerHTML = '';

        if (list.length > 0) {
            list.forEach(model => {
                const option = document.createElement('option');
                option.value = model;
                option.textContent = model;
                if (model === currentModel) option.selected = true;
                modelSelect.appendChild(option);
            });
            if (!modelSelect.value && currentModel) {
                const option = document.createElement('option');
                option.value = currentModel;
                option.textContent = currentModel;
                option.selected = true;
                modelSelect.appendChild(option);
            }
            if (!modelSelect.value && modelSelect.options.length > 0) {
                modelSelect.selectedIndex = 0;
            }
            return;
        }

        if (currentModel) {
            const option = document.createElement('option');
            option.value = currentModel;
            option.textContent = currentModel;
            option.selected = true;
            modelSelect.appendChild(option);
        } else {
            modelSelect.innerHTML = '<option value="" disabled selected>请先获取模型</option>';
        }
    }

    function populateTiagangModelSelect(models = [], currentModel = '') {
        const modelSelect = document.getElementById('wbap-tiagang-model');
        if (!modelSelect) return;
        const list = Array.isArray(models) ? models : [];
        modelSelect.innerHTML = '';

        if (list.length > 0) {
            list.forEach(model => {
                const option = document.createElement('option');
                option.value = model;
                option.textContent = model;
                if (model === currentModel) option.selected = true;
                modelSelect.appendChild(option);
            });
            if (!modelSelect.value && currentModel) {
                const option = document.createElement('option');
                option.value = currentModel;
                option.textContent = currentModel;
                option.selected = true;
                modelSelect.appendChild(option);
            }
            if (!modelSelect.value && modelSelect.options.length > 0) {
                modelSelect.selectedIndex = 0;
            }
            return;
        }

        if (currentModel) {
            const option = document.createElement('option');
            option.value = currentModel;
            option.textContent = currentModel;
            option.selected = true;
            modelSelect.appendChild(option);
        } else {
            modelSelect.innerHTML = '<option value="" disabled selected>\u8bf7\u5148\u83b7\u53d6\u6a21\u578b</option>';
        }
    }

    async function populateTiagangWorldbookSelect() {
        const select = document.getElementById('wbap-tiagang-worldbook-select');
        if (!select) return;
        select.innerHTML = '<option value="">-- \u8bf7\u9009\u62e9 --</option>';
        try {
            const names = await WBAP.getAllWorldBookNames?.();
            if (Array.isArray(names)) {
                names.forEach(name => {
                    const option = document.createElement('option');
                    option.value = name;
                    option.textContent = name;
                    select.appendChild(option);
                });
            }
        } catch (err) {
            Logger.warn('Failed to load worldbook list for tiangang', err);
        }
    }

    function renderTiagangSelectedWorldbooks(tgCfg) {
        const container = document.getElementById('wbap-tiagang-selected-worldbooks');
        if (!container) return;
        if (!tgCfg.worldBooks || tgCfg.worldBooks.length === 0) {
            container.innerHTML = '<small class="wbap-text-muted">\u5c1a\u672a\u9009\u62e9\u4e16\u754c\u4e66</small>';
            return;
        }
        container.innerHTML = tgCfg.worldBooks.map(name => `
            <span class="wbap-tag" style="background: var(--wbap-bg-secondary, #2a2a3a); padding: 4px 8px; border-radius: 12px; display: inline-flex; align-items: center; gap: 6px;">
                <span>${name}</span>
                <button type="button" data-remove-book="${name}" class="wbap-btn wbap-btn-xs wbap-btn-icon" style="padding: 0 6px;">&times;</button>
            </span>
        `).join('');
    }

    function renderTiagangWorldbookList(tgCfg) {
        const container = document.getElementById('wbap-tiagang-book-list-container');
        if (!container) return;
        const names = Array.isArray(tgCfg.worldBooks) ? tgCfg.worldBooks : [];
        if (names.length === 0) {
            container.innerHTML = '<p class="wbap-text-muted" style="padding: 8px; text-align: center; font-size: 12px;">\u8bf7\u5148\u6dfb\u52a0\u4e16\u754c\u4e66</p>';
            return;
        }
        container.innerHTML = names.map(name => `
            <div class="wbap-book-item${name === tiagangActiveWorldbook ? ' active' : ''}" data-book-name="${name}">
                ${name}
            </div>
        `).join('');
    }

    async function renderTiagangEntryList(bookName) {
        const entryList = document.getElementById('wbap-tiagang-entry-list');
        if (!entryList) return;
        if (!bookName) {
            entryList.innerHTML = '<p class="wbap-text-muted" style="text-align: center; font-size: 12px;">\u8bf7\u4ece\u5de6\u4fa7\u9009\u62e9\u4e00\u672c\u4e16\u754c\u4e66</p>';
            return;
        }

        entryList.innerHTML = '<p class="wbap-text-muted" style="text-align: center;"><i class="fa-solid fa-spinner fa-spin"></i> \u6b63\u5728\u52a0\u8f7d\u6761\u76ee...</p>';
        let entries = tiagangWorldbookCache.get(bookName);
        if (!entries) {
            const book = await WBAP.loadWorldBookEntriesByName(bookName);
            entries = book?.entries || null;
            tiagangWorldbookCache.set(bookName, entries);
        }
        if (!entries) {
            entryList.innerHTML = `<p style="color: var(--wbap-danger); text-align: center;">\u52a0\u8f7d\u4e16\u754c\u4e66 ${bookName} \u5931\u8d25</p>`;
            return;
        }

        const enabledEntries = Object.entries(entries).filter(([, entry]) => entry && entry.disable !== true);
        if (enabledEntries.length === 0) {
            entryList.innerHTML = '<p class="wbap-text-muted" style="text-align: center; font-size: 12px;">\u8be5\u4e16\u754c\u4e66\u65e0\u53ef\u7528\u6761\u76ee</p>';
            return;
        }

        const config = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
        const tgCfg = ensureTiagangConfig(config);
        const selected = new Set(tgCfg.assignedEntriesMap?.[bookName] || []);

        entryList.innerHTML = enabledEntries.map(([uid, entry]) => {
            const label = entry?.comment || uid;
            const checked = selected.has(uid) ? 'checked' : '';
            return `
                <label>
                    <input type="checkbox" data-entry="${encodeURIComponent(uid)}" ${checked}>
                    <span>${label}</span>
                </label>
            `;
        }).join('');

        entryList.querySelectorAll('input[type="checkbox"]').forEach(cb => {
            cb.addEventListener('change', (e) => {
                const entryId = decodeURIComponent(e.target.dataset.entry);
                const next = new Set(tgCfg.assignedEntriesMap?.[bookName] || []);
                if (e.target.checked) {
                    next.add(entryId);
                } else {
                    next.delete(entryId);
                }
                tgCfg.assignedEntriesMap[bookName] = Array.from(next);
                WBAP.saveConfig();
            });
        });
    }

    function renderTiagangWorldbookUI() {
        const config = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
        if (!config) return;
        const tgCfg = ensureTiagangConfig(config);
        if (!tiagangActiveWorldbook || !tgCfg.worldBooks.includes(tiagangActiveWorldbook)) {
            tiagangActiveWorldbook = tgCfg.worldBooks[0] || null;
        }
        renderTiagangSelectedWorldbooks(tgCfg);
        renderTiagangWorldbookList(tgCfg);
        renderTiagangEntryList(tiagangActiveWorldbook);
    }

    function addTiagangWorldbook(bookName) {
        if (!bookName) return;
        const config = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
        if (!config) return;
        const tgCfg = ensureTiagangConfig(config);
        if (!tgCfg.worldBooks.includes(bookName)) {
            tgCfg.worldBooks.push(bookName);
        }
        tiagangActiveWorldbook = bookName;
        WBAP.saveConfig();
        renderTiagangWorldbookUI();
    }

    function removeTiagangWorldbook(bookName) {
        if (!bookName) return;
        const config = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
        if (!config) return;
        const tgCfg = ensureTiagangConfig(config);
        tgCfg.worldBooks = (tgCfg.worldBooks || []).filter(name => name !== bookName);
        if (tgCfg.assignedEntriesMap) {
            delete tgCfg.assignedEntriesMap[bookName];
        }
        if (tiagangActiveWorldbook === bookName) {
            tiagangActiveWorldbook = tgCfg.worldBooks[0] || null;
        }
        WBAP.saveConfig();
        renderTiagangWorldbookUI();
    }

    function setTiagangEntrySelection(selectAll) {
        if (!tiagangActiveWorldbook) return;
        const entryList = document.getElementById('wbap-tiagang-entry-list');
        if (!entryList) return;
        const checkboxes = entryList.querySelectorAll('input[type="checkbox"]');
        const ids = [];
        checkboxes.forEach(cb => {
            cb.checked = !!selectAll;
            if (selectAll) {
                ids.push(decodeURIComponent(cb.dataset.entry));
            }
        });
        const config = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
        if (!config) return;
        const tgCfg = ensureTiagangConfig(config);
        tgCfg.assignedEntriesMap[tiagangActiveWorldbook] = selectAll ? ids : [];
        WBAP.saveConfig();
    }

    function loadTiagangSettingsToUI() {
        const config = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
        if (!config) return;
        const tgCfg = ensureTiagangConfig(config);

        const enabledEl = document.getElementById('wbap-tiagang-enabled');
        if (enabledEl) enabledEl.checked = tgCfg.enabled === true;

        const roundsEl = document.getElementById('wbap-tiagang-context-rounds');
        const roundsValEl = document.getElementById('wbap-tiagang-context-rounds-value');
        if (roundsEl && roundsValEl) {
            const safeRounds = Number.isFinite(tgCfg.contextRounds) ? tgCfg.contextRounds : 5;
            roundsEl.value = safeRounds;
            roundsValEl.textContent = safeRounds;
        }

        const apiCfg = tgCfg.apiConfig || {};
        const apiUrlEl = document.getElementById('wbap-tiagang-api-url');
        const apiKeyEl = document.getElementById('wbap-tiagang-api-key');
        const maxTokensEl = document.getElementById('wbap-tiagang-max-tokens');
        const tempEl = document.getElementById('wbap-tiagang-temperature');
        const timeoutEl = document.getElementById('wbap-tiagang-timeout');
        const maxRetriesEl = document.getElementById('wbap-tiagang-max-retries');
        const retryDelayEl = document.getElementById('wbap-tiagang-retry-delay');
        const streamingEl = document.getElementById('wbap-tiagang-streaming');
        if (apiUrlEl) apiUrlEl.value = apiCfg.apiUrl || '';
        if (apiKeyEl) apiKeyEl.value = apiCfg.apiKey || '';
        if (maxTokensEl) maxTokensEl.value = apiCfg.maxTokens || 2000;
        if (tempEl) tempEl.value = apiCfg.temperature ?? 0.7;
        if (timeoutEl) timeoutEl.value = apiCfg.timeout ?? 60;
        if (maxRetriesEl) maxRetriesEl.value = Number.isFinite(apiCfg.maxRetries) ? apiCfg.maxRetries : 2;
        if (retryDelayEl) retryDelayEl.value = Number.isFinite(apiCfg.retryDelayMs) ? apiCfg.retryDelayMs : 800;
        if (streamingEl) streamingEl.checked = apiCfg.enableStreaming !== false;
        populateTiagangModelSelect([], apiCfg.model || '');

        populateTiagangWorldbookSelect();
        refreshTiagangPromptList();
        renderTiagangWorldbookUI();
    }

    function saveTiagangSettings() {
        const config = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
        if (!config) return;
        const tgCfg = ensureTiagangConfig(config);

        const enabledEl = document.getElementById('wbap-tiagang-enabled');
        if (enabledEl) tgCfg.enabled = enabledEl.checked === true;

        const roundsVal = parseInt(document.getElementById('wbap-tiagang-context-rounds')?.value, 10);
        tgCfg.contextRounds = Number.isFinite(roundsVal) ? roundsVal : (tgCfg.contextRounds ?? 5);

        const apiCfg = tgCfg.apiConfig || {};
        apiCfg.apiUrl = document.getElementById('wbap-tiagang-api-url')?.value || '';
        apiCfg.apiKey = document.getElementById('wbap-tiagang-api-key')?.value || '';
        apiCfg.model = document.getElementById('wbap-tiagang-model')?.value || '';
        const maxTokensVal = parseInt(document.getElementById('wbap-tiagang-max-tokens')?.value, 10);
        apiCfg.maxTokens = Number.isFinite(maxTokensVal) && maxTokensVal > 0 ? maxTokensVal : 2000;
        const tempVal = parseFloat(document.getElementById('wbap-tiagang-temperature')?.value);
        apiCfg.temperature = Number.isFinite(tempVal) ? tempVal : 0.7;
        const timeoutVal = parseInt(document.getElementById('wbap-tiagang-timeout')?.value, 10);
        apiCfg.timeout = Number.isFinite(timeoutVal) && timeoutVal > 0 ? timeoutVal : 60;
        const retriesVal = parseInt(document.getElementById('wbap-tiagang-max-retries')?.value, 10);
        apiCfg.maxRetries = Number.isFinite(retriesVal) && retriesVal >= 0 ? retriesVal : 2;
        const retryDelayVal = parseInt(document.getElementById('wbap-tiagang-retry-delay')?.value, 10);
        apiCfg.retryDelayMs = Number.isFinite(retryDelayVal) && retryDelayVal > 0 ? retryDelayVal : 800;
        apiCfg.enableStreaming = document.getElementById('wbap-tiagang-streaming')?.checked !== false;
        tgCfg.apiConfig = apiCfg;

        if (apiCfg.apiUrl && WBAP.setupPreconnect) {
            WBAP.setupPreconnect([{ apiUrl: apiCfg.apiUrl }]);
        }

        WBAP.saveConfig();

        const btn = document.getElementById('wbap-tiagang-save');
        if (btn) {
            const original = btn.innerHTML;
            btn.innerHTML = '<i class="fa-solid fa-check"></i> \u5df2\u4fdd\u5b58';
            setTimeout(() => {
                btn.innerHTML = original;
            }, 1500);
        }
    }

    function loadSettingsToUI() {
        const config = WBAP.CharacterManager.getCurrentCharacterConfig();
        if (!config) return;
        if (!config.aggregatorMode) {
            config.aggregatorMode = { enabled: false, endpointId: '', promptIndex: 0, allowDuplicate: false };
        } else if (config.aggregatorMode.allowDuplicate == null) {
            config.aggregatorMode.allowDuplicate = false;
        }

        document.getElementById('wbap-enabled').checked = config.enabled !== false;

        const global = WBAP.mainConfig.globalSettings || {};
        const maxConcEl = document.getElementById('wbap-global-max-concurrent');
        const timeoutEl = document.getElementById('wbap-global-timeout');
        if (maxConcEl) maxConcEl.value = global.maxConcurrent ?? 0;
        if (timeoutEl) timeoutEl.value = global.timeout ?? 0;
        const superConcEl = document.getElementById('wbap-super-concurrency');
        if (superConcEl) {
            superConcEl.checked = global.enableSuperConcurrency === true;
            toggleSuperConcurrencySection(superConcEl.checked);
        }

        const contextRoundsEl = document.getElementById('wbap-context-rounds');
        const contextRoundsValue = document.getElementById('wbap-context-rounds-value');
        if (contextRoundsEl && contextRoundsValue) {
            const safeRounds = Number.isFinite(config.contextRounds) ? config.contextRounds : 5;
            contextRoundsEl.value = safeRounds;
            contextRoundsValue.textContent = safeRounds;
        }

        const chunkingEl = document.getElementById('wbap-enable-chunking');
        if (chunkingEl) {
            chunkingEl.checked = config.enableChunking === true;
        }

        const skipProcessedEl = document.getElementById('wbap-skip-processed');
        if (skipProcessedEl) {
            skipProcessedEl.checked = config.skipProcessedMessages !== false;
        }
        const tagNameEl = document.getElementById('wbap-tag-extraction-name');
        if (tagNameEl) {
            tagNameEl.value = config.tagExtractionName || '';
        }
        const mergeWorldbooksEl = document.getElementById('wbap-merge-worldbooks');
        if (mergeWorldbooksEl) {
            mergeWorldbooksEl.checked = config.mergeWorldBooks !== false;
        }
        const useSelectedWorldbooksEl = document.getElementById('wbap-use-selected-worldbooks');
        if (useSelectedWorldbooksEl) {
            useSelectedWorldbooksEl.checked = config.useSelectedWorldBooks !== false;
        }

        const superCfg = ensureSuperConcurrencyConfig(config);
        const superModeEl = document.getElementById('wbap-super-concurrency-mode');
        if (superModeEl) {
            superModeEl.value = superCfg.mode || 'basic';
            toggleSuperConcurrencyMode(superModeEl.value);
        }
        const superRoundsEl = document.getElementById('wbap-super-concurrency-rounds');
        if (superRoundsEl) {
            superRoundsEl.value = superCfg.reviewRounds || 1;
        }
        const superShowPanelEl = document.getElementById('wbap-super-concurrency-show-panel');
        if (superShowPanelEl) {
            superShowPanelEl.checked = superCfg.showPanel !== false;
        }

        const showProgressPanelEl = document.getElementById('wbap-settings-progress-panel');
        if (showProgressPanelEl) {
            showProgressPanelEl.checked = config.showProgressPanel !== false;
        }

        const optimizationEl = document.getElementById('wbap-settings-plot-optimization');
        if (optimizationEl) {
            optimizationEl.checked = config.enablePlotOptimization === true;
        }
        const optimizationFabEl = document.getElementById('wbap-settings-plot-optimization-fab');
        if (optimizationFabEl) {
            optimizationFabEl.checked = config.enablePlotOptimizationFloatButton === true;
        }

        // 三级优化开关
        const level3EnabledEl = document.getElementById('wbap-settings-level3-enabled');
        if (level3EnabledEl) {
            level3EnabledEl.checked = config.optimizationLevel3?.enabled === true;
        }

        // 根据启用状态展开/折叠设置区域
        setOptimizationSectionState(config.enablePlotOptimization === true);

        refreshOptimizationPromptList();
        const optimizationApiConfig = ensureOptimizationApiConfig(config);
        const optimizationUseEl = document.getElementById('wbap-optimization-use-independent');
        if (optimizationUseEl) {
            optimizationUseEl.checked = optimizationApiConfig.useIndependentProfile === true;
        }
        toggleOptimizationApiBlocks(optimizationApiConfig.useIndependentProfile === true);
        renderOptimizationEndpointOptions(optimizationApiConfig.selectedEndpointId);
        const optimizationUrlEl = document.getElementById('wbap-optimization-api-url');
        if (optimizationUrlEl) optimizationUrlEl.value = optimizationApiConfig.apiUrl || '';
        const optimizationKeyEl = document.getElementById('wbap-optimization-api-key');
        if (optimizationKeyEl) optimizationKeyEl.value = optimizationApiConfig.apiKey || '';
        const optimizationMaxTokensEl = document.getElementById('wbap-optimization-max-tokens');
        if (optimizationMaxTokensEl) optimizationMaxTokensEl.value = optimizationApiConfig.maxTokens || 4000;
        const optimizationTempEl = document.getElementById('wbap-optimization-temperature');
        if (optimizationTempEl) optimizationTempEl.value = optimizationApiConfig.temperature ?? 0.7;
        const optimizationTimeoutEl = document.getElementById('wbap-optimization-timeout');
        if (optimizationTimeoutEl) optimizationTimeoutEl.value = optimizationApiConfig.timeout ?? 60;
        const optimizationRetriesEl = document.getElementById('wbap-optimization-max-retries');
        if (optimizationRetriesEl) optimizationRetriesEl.value = Number.isFinite(optimizationApiConfig.maxRetries) ? optimizationApiConfig.maxRetries : 2;
        const optimizationRetryDelayEl = document.getElementById('wbap-optimization-retry-delay');
        if (optimizationRetryDelayEl) optimizationRetryDelayEl.value = Number.isFinite(optimizationApiConfig.retryDelayMs) ? optimizationApiConfig.retryDelayMs : 800;
        const optimizationStreamingEl = document.getElementById('wbap-optimization-streaming');
        if (optimizationStreamingEl) optimizationStreamingEl.checked = optimizationApiConfig.enableStreaming !== false;
        populateOptimizationModelSelect([], optimizationApiConfig.model || '');

        renderApiEndpoints();
        renderAggregatorControls();
        refreshPromptList();
        refreshSecondaryPromptUI();
        refreshCabinetPromptList();
        loadTiagangSettingsToUI();
        if (WBAP.Optimization && typeof WBAP.Optimization.updateFloatingButtonVisibility === 'function') {
            WBAP.Optimization.updateFloatingButtonVisibility();
        }
    }

    function renderApiEndpoints() {
        const listContainer = document.getElementById('wbap-api-endpoint-list');
        if (!listContainer) return;

        const config = WBAP.CharacterManager.getCurrentCharacterConfig();
        const endpoints = config?.selectiveMode?.apiEndpoints || [];
        renderOptimizationEndpointOptions(config?.optimizationApiConfig?.selectedEndpointId || null);

        if (endpoints.length === 0) {
            listContainer.innerHTML = '<div class="wbap-empty-state"><p>没有API实例。请点击上方按钮添加一个。</p></div>';
            return;
        }

        listContainer.innerHTML = endpoints.map((ep) => `
            <div class="wbap-api-endpoint-item" data-id="${ep.id}">
                <div class="wbap-api-endpoint-header">
                    <label style="display:flex; gap:8px; align-items:center;">
                        <input type="checkbox" class="wbap-endpoint-enabled" data-id="${ep.id}" ${ep.enabled === false ? '' : 'checked'}>
                        <span>${ep.name}（${(Object.values(ep.assignedEntriesMap || {}).reduce((sum, arr) => sum + (arr?.length || 0), 0) || ep.assignedEntries?.length || 0)} 条，${(Array.isArray(ep.worldBooks) ? ep.worldBooks : (ep.worldBook ? [ep.worldBook] : ['未选择'])).join(', ')}）</span>
                    </label>
                    <div>
                        <button class="wbap-btn wbap-btn-icon wbap-btn-xs" onclick="window.wbapEditEndpoint('${ep.id}')" title="编辑API实例">
                            <i class="fa-solid fa-pencil"></i>
                        </button>
                        <button class="wbap-btn wbap-btn-icon wbap-btn-danger wbap-btn-xs" onclick="window.wbapDeleteEndpoint('${ep.id}')" title="删除">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `).join('');

        // 勾选状态变更
        listContainer.querySelectorAll('.wbap-endpoint-enabled').forEach(cb => {
            cb.addEventListener('change', (e) => {
                const id = e.currentTarget.dataset.id;
                const target = endpoints.find(item => item.id === id);
                if (target) {
                    target.enabled = e.currentTarget.checked;
                    WBAP.saveConfig();
                }
            });
        });

        renderAggregatorControls();
        refreshPromptList();
    }

    function renderAggregatorControls() {
        const cfg = WBAP.CharacterManager.getCurrentCharacterConfig();
        if (!cfg.aggregatorMode) {
            cfg.aggregatorMode = { enabled: false, endpointId: '', promptIndex: 0, allowDuplicate: false };
        } else if (cfg.aggregatorMode.allowDuplicate == null) {
            cfg.aggregatorMode.allowDuplicate = false;
        }

        const enabledEl = document.getElementById('wbap-agg-enabled');
        const endpointEl = document.getElementById('wbap-agg-endpoint');
        const promptEl = document.getElementById('wbap-agg-prompt');
        const allowDuplicateEl = document.getElementById('wbap-agg-allow-duplicate');
        if (!enabledEl || !endpointEl || !promptEl) return;

        enabledEl.checked = cfg.aggregatorMode.enabled === true;
        if (allowDuplicateEl) {
            allowDuplicateEl.checked = cfg.aggregatorMode.allowDuplicate === true;
        }

        const endpoints = cfg?.selectiveMode?.apiEndpoints || [];
        endpointEl.innerHTML = '';
        if (endpoints.length === 0) {
            endpointEl.innerHTML = '<option value=\"\">请先新增 API 实例</option>';
            endpointEl.disabled = true;
        } else {
            endpointEl.disabled = false;
            endpoints.forEach(ep => {
                const opt = document.createElement('option');
                opt.value = ep.id;
                opt.textContent = ep.name || ep.id;
                endpointEl.appendChild(opt);
            });
            endpointEl.value = cfg.aggregatorMode.endpointId || '';
        }

        const prompts = WBAP.PromptManager.getCombinedPrompts();
        promptEl.innerHTML = '';
        if (prompts.length === 0) {
            promptEl.innerHTML = '<option value=\"0\">暂无提示词</option>';
            promptEl.disabled = true;
        } else {
            promptEl.disabled = false;
            prompts.forEach((p, idx) => {
                const opt = document.createElement('option');
                opt.value = idx;
                opt.textContent = p.name || `预设${idx + 1}`;
                promptEl.appendChild(opt);
            });
            let idx = cfg.aggregatorMode.promptIndex || 0;
            if (idx >= prompts.length) idx = prompts.length - 1;
            promptEl.value = idx;
            cfg.aggregatorMode.promptIndex = idx;
        }
    }

    function refreshOptimizationPromptList() {
        const selectEl = document.getElementById('wbap-opt-prompt-select');
        const descEl = document.getElementById('wbap-opt-prompt-desc');
        const editBtn = document.getElementById('wbap-opt-prompt-edit-btn');
        const exportBtn = document.getElementById('wbap-opt-prompt-export-btn');
        const deleteBtn = document.getElementById('wbap-opt-prompt-delete-btn');
        if (!selectEl || !descEl) return;

        const config = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
        const level3Cfg = ensureOptimizationPromptConfig(config);
        const presets = level3Cfg.promptPresets || [];
        const hasPresets = presets.length > 0;

        selectEl.disabled = !hasPresets;
        if (editBtn) editBtn.disabled = !hasPresets;
        if (exportBtn) exportBtn.disabled = !hasPresets;
        if (deleteBtn) deleteBtn.disabled = !hasPresets;

        if (!hasPresets) {
            selectEl.innerHTML = '<option>无可用预设</option>';
            descEl.textContent = '请新建或导入一个提示词预设。';
            return;
        }

        let idx = level3Cfg.selectedPromptIndex || 0;
        if (idx >= presets.length) {
            idx = presets.length - 1;
            level3Cfg.selectedPromptIndex = idx;
            WBAP.saveConfig();
        }

        selectEl.innerHTML = presets.map((p, index) => `<option value="${index}">${p.name || `未命名预设 ${index + 1}`}</option>`).join('');
        selectEl.value = idx;
        descEl.textContent = presets[idx]?.description || '此预设没有描述。';
        WBAP.Optimization?.updatePromptLabel?.();
    }


    function refreshPromptList() {
        const selectEl = document.getElementById('wbap-prompt-preset-select');
        const descriptionArea = document.getElementById('wbap-prompt-description-area');
        const editBtn = document.getElementById('wbap-prompt-edit-btn');
        const exportBtn = document.getElementById('wbap-prompt-export-btn');
        const deleteBtn = document.getElementById('wbap-prompt-delete-btn');
        const bindingSummary = document.getElementById('wbap-prompt-binding-summary');
        const secondarySelect = document.getElementById('wbap-secondary-preset-select');
        const secondaryDesc = document.getElementById('wbap-secondary-description-area');
        if (!selectEl || !descriptionArea) return;

        // 确保从当前角色的配置读取
        const currentConfig = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
        const prompts = WBAP.PromptManager.getCombinedPrompts();
        let selectedIndex = currentConfig.selectedPromptIndex || 0;
        const hasPrompts = prompts.length > 0;

        selectEl.disabled = !hasPrompts;
        editBtn.disabled = !hasPrompts;
        exportBtn.disabled = !hasPrompts;
        deleteBtn.disabled = !hasPrompts;
        if (secondarySelect) secondarySelect.disabled = !hasPrompts;

        if (!hasPrompts) {
            selectEl.innerHTML = '<option>无可用预设</option>';
            descriptionArea.textContent = '请新建或导入一个提示词预设。';
            if (bindingSummary) bindingSummary.textContent = '';
            if (secondarySelect) secondarySelect.innerHTML = '<option>无可用预设</option>';
            if (secondaryDesc) secondaryDesc.textContent = '请新建或导入一个提示词预设。';
            return;
        }

        if (selectedIndex >= prompts.length) {
            selectedIndex = prompts.length - 1;
            currentConfig.selectedPromptIndex = selectedIndex;
            // 同步更新全局 config
            if (WBAP.config !== currentConfig) {
                WBAP.config.selectedPromptIndex = selectedIndex;
            }
            WBAP.saveConfig();
        }

        selectEl.innerHTML = prompts.map((p, index) => `<option value="${index}">${p.name || `未命名预设 ${index + 1}`}</option>`).join('');
        selectEl.value = selectedIndex;
        descriptionArea.textContent = prompts[selectedIndex].description || '此预设没有描述。';
        if (bindingSummary) {
            const boundIds = Array.isArray(prompts[selectedIndex].boundEndpointIds) ? prompts[selectedIndex].boundEndpointIds.filter(Boolean) : [];
            const endpoints = currentConfig?.selectiveMode?.apiEndpoints || [];
            const nameMap = new Map(endpoints.map(ep => [ep.id, ep.name || ep.id]));
            if (boundIds.length === 0) {
                bindingSummary.textContent = '未绑定 API（将使用所有已配置实例）。';
            } else {
                const names = boundIds.map(id => nameMap.get(id) || id);
                bindingSummary.textContent = `已绑定 ${boundIds.length} 个 API：${names.join(', ')}`;
            }
        }
        const boundIdsMain = Array.isArray(prompts[selectedIndex].boundEndpointIds) ? prompts[selectedIndex].boundEndpointIds.filter(Boolean) : [];
        renderPromptBindingList(boundIdsMain);
        updatePromptBindingTags(boundIdsMain);
        refreshPromptVariables();

        // 副提示词下拉
        if (secondarySelect) {
            let secondaryIndex = currentConfig?.secondaryPrompt?.selectedPromptIndex ?? 0;
            if (secondaryIndex >= prompts.length) {
                secondaryIndex = prompts.length - 1;
                if (!currentConfig.secondaryPrompt) currentConfig.secondaryPrompt = { enabled: false, selectedPromptIndex: 0, boundEndpointIds: [] };
                currentConfig.secondaryPrompt.selectedPromptIndex = secondaryIndex;
                if (WBAP.config !== currentConfig) {
                    WBAP.config.secondaryPrompt = currentConfig.secondaryPrompt;
                }
                WBAP.saveConfig();
            }
            secondarySelect.innerHTML = prompts.map((p, index) => `<option value="${index}">${p.name || `未命名预设 ${index + 1}`}</option>`).join('');
            secondarySelect.value = secondaryIndex;
            if (secondaryDesc) {
                secondaryDesc.textContent = prompts[secondaryIndex]?.description || '此预设没有描述。';
            }
            refreshSecondaryPromptUI();
        }

        // 保证总局下拉实时同步最新提示词列表（含导入）
        renderAggregatorControls();
    }

    function refreshPromptVariables() {
        const container = document.getElementById('wbap-prompt-variables-container');
        if (!container) return;
        container.innerHTML = '';

        // 确保从当前角色的配置读取（角色切换后 WBAP.config 应该已经指向新角色的配置）
        const currentConfig = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
        const combinedPrompts = WBAP.PromptManager.getCombinedPrompts();
        const selectedIndex = currentConfig.selectedPromptIndex ?? 0;
        const prompt = combinedPrompts?.[selectedIndex];
        if (!prompt || !prompt.name) return;
        const promptName = prompt.name;
        const variables = prompt.variables || {};

        const updateVariable = (key, value) => {
            const latestPrompts = WBAP.PromptManager.getCombinedPrompts();
            const latestPrompt = latestPrompts.find(p => p.name === promptName);
            if (!latestPrompt) return;
            const nextPrompt = {
                ...latestPrompt,
                variables: {
                    ...(latestPrompt.variables || {}),
                    [key]: value
                }
            };
            WBAP.PromptManager.addOrUpdatePrompt(nextPrompt);
            Logger.log(`变量 ${key} 已保存到角色配置: ${value}`);
        };

        for (let i = 1; i <= 4; i++) {
            const key = `sulv${i}`;
            const value = variables[key] || '';
            const item = document.createElement('div');
            item.className = 'wbap-variable-item';
            item.innerHTML = `<label for="wbap-var-${key}">${key}</label><input type="text" id="wbap-var-${key}" value="${value}" placeholder="变量 ${key} 的值">`;
            const inputEl = item.querySelector('input');
            inputEl.addEventListener('input', (e) => {
                updateVariable(key, e.target.value);
            });
            container.appendChild(item);
        }
    }

    function refreshSecondaryPromptUI() {
        const cfg = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
        const prompts = WBAP.PromptManager.getCombinedPrompts();
        const secondarySelect = document.getElementById('wbap-secondary-preset-select');
        const secondaryDesc = document.getElementById('wbap-secondary-description-area');
        const secondaryEnabled = document.getElementById('wbap-secondary-enabled');
        const bindingList = document.getElementById('wbap-secondary-binding-list');
        if (!secondarySelect || !secondaryDesc || !secondaryEnabled) return;

        const hasPrompts = prompts.length > 0;
        secondarySelect.disabled = !hasPrompts;
        if (!hasPrompts) {
            secondaryDesc.textContent = '请新建或导入一个提示词预设。';
            updateSecondaryBindingSummary([]);
            if (bindingList) bindingList.innerHTML = '<small class="wbap-text-muted">暂无已配置的 API 实例。</small>';
            return;
        }

        if (!cfg.secondaryPrompt) {
            cfg.secondaryPrompt = { enabled: false, selectedPromptIndex: 0, boundEndpointIds: [] };
        }

        secondaryEnabled.checked = cfg.secondaryPrompt.enabled === true;

        let idx = cfg.secondaryPrompt.selectedPromptIndex ?? 0;
        if (idx >= prompts.length) {
            idx = prompts.length - 1;
            cfg.secondaryPrompt.selectedPromptIndex = idx;
            if (WBAP.config !== cfg) {
                WBAP.config.secondaryPrompt = cfg.secondaryPrompt;
            }
            WBAP.saveConfig();
        }
        secondarySelect.value = idx;
        secondaryDesc.textContent = prompts[idx]?.description || '此预设没有描述。';

        const boundIds = Array.isArray(cfg.secondaryPrompt.boundEndpointIds) ? cfg.secondaryPrompt.boundEndpointIds : [];
        renderSecondaryBindingList(boundIds);
        updateSecondaryBindingSummary(boundIds);
    }

    function updatePromptBindingTags(selectedIds = [], endpoints = null) {
        const tagsEl = document.getElementById('wbap-prompt-bound-apis');
        if (!tagsEl) return;
        const eps = endpoints || (WBAP.CharacterManager.getCurrentCharacterConfig()?.selectiveMode?.apiEndpoints || []);
        if (!selectedIds || selectedIds.length === 0) {
            tagsEl.innerHTML = '<small class="wbap-text-muted">未绑定（默认使用全部）</small>';
            return;
        }
        const map = new Map(eps.map(ep => [ep.id, ep.name || ep.id]));
        tagsEl.innerHTML = selectedIds.map(id => {
            const name = map.get(id) || id;
            return `<span class="wbap-tag" style="background: var(--wbap-bg-secondary, #2a2a3a); padding: 4px 8px; border-radius: 12px; display: inline-flex; align-items: center;">${name}</span>`;
        }).join('');
    }

    function updateSecondaryBindingSummary(selectedIds = []) {
        const summaryEl = document.getElementById('wbap-secondary-binding-summary');
        if (!summaryEl) return;
        const currentConfig = WBAP.CharacterManager.getCurrentCharacterConfig();
        const endpoints = currentConfig?.selectiveMode?.apiEndpoints || [];
        const map = new Map(endpoints.map(ep => [ep.id, ep.name || ep.id]));
        if (!selectedIds || selectedIds.length === 0) {
            summaryEl.textContent = '未绑定 API（将使用所有已配置实例）。';
            return;
        }
        const names = selectedIds.map(id => map.get(id) || id);
        summaryEl.textContent = `已绑定 ${selectedIds.length} 个 API：${names.join(', ')}`;
    }

    function renderSecondaryBindingList(selectedIds = []) {
        const listEl = document.getElementById('wbap-secondary-binding-list');
        if (!listEl) return;
        const currentConfig = WBAP.CharacterManager.getCurrentCharacterConfig();
        const endpoints = currentConfig?.selectiveMode?.apiEndpoints || [];
        const selected = new Set(selectedIds);
        if (endpoints.length === 0) {
            listEl.innerHTML = '<small class="wbap-text-muted">暂无已配置的 API 实例。</small>';
        } else {
            listEl.innerHTML = endpoints.map(ep => {
                const checked = selected.has(ep.id) ? 'checked' : '';
                return `<label style="display: flex; align-items: center; gap: 6px; margin-bottom: 6px;"><input type="checkbox" value="${ep.id}" ${checked}> <span>${ep.name || ep.id}</span></label>`;
            }).join('');
        }
    }

    function getSecondaryBindingSelection() {
        return Array.from(document.querySelectorAll('#wbap-secondary-binding-list input[type="checkbox"]:checked')).map(cb => cb.value);
    }

    function renderPromptBindingList(selectedIds = []) {
        const listEl = document.getElementById('wbap-prompt-binding-list');
        if (!listEl) return;
        const currentConfig = WBAP.CharacterManager.getCurrentCharacterConfig();
        const endpoints = currentConfig?.selectiveMode?.apiEndpoints || [];
        const selected = new Set(selectedIds);
        if (endpoints.length === 0) {
            listEl.innerHTML = '<small class="wbap-text-muted">暂无已配置的 API 实例。</small>';
        } else {
            listEl.innerHTML = endpoints.map(ep => {
                const checked = selected.has(ep.id) ? 'checked' : '';
                return `<label style="display: flex; align-items: center; gap: 6px; margin-bottom: 6px;"><input type="checkbox" value="${ep.id}" ${checked}> <span>${ep.name || ep.id}</span></label>`;
            }).join('');
        }
        listEl.style.display = 'none';
        updatePromptBindingTags(selectedIds, endpoints);
    }

    function getPromptBindingSelection() {
        return Array.from(document.querySelectorAll('#wbap-prompt-binding-list input[type="checkbox"]:checked')).map(cb => cb.value);
    }

    function updatePromptBindingSummary(selectedIds = []) {
        const bindingSummary = document.getElementById('wbap-prompt-binding-summary');
        if (!bindingSummary) return;
        const currentConfig = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
        const endpoints = currentConfig?.selectiveMode?.apiEndpoints || [];
        const nameMap = new Map(endpoints.map(ep => [ep.id, ep.name || ep.id]));
        if (selectedIds.length === 0) {
            bindingSummary.textContent = '未绑定 API（将使用所有已配置实例）。';
        } else {
            const names = selectedIds.map(id => nameMap.get(id) || id);
            bindingSummary.textContent = `已绑定 ${selectedIds.length} 个 API：${names.join(', ')}`;
        }
    }

    function bindEditorEvents() {
        document.getElementById('wbap-prompt-editor-close')?.addEventListener('click', closePromptEditor);
        document.getElementById('wbap-prompt-editor-cancel')?.addEventListener('click', closePromptEditor);
        document.getElementById('wbap-prompt-editor-save')?.addEventListener('click', savePrompt);

        // 占位符按钮点击插入
        const placeholderButtons = document.querySelectorAll('.wbap-placeholder-btn');
        placeholderButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const placeholder = e.target.dataset.placeholder;
                const activeElement = document.activeElement;
                if (activeElement && (activeElement.id === 'wbap-prompt-edit-system' || activeElement.id === 'wbap-prompt-edit-main' || activeElement.id === 'wbap-prompt-edit-final-directive')) {
                    const start = activeElement.selectionStart;
                    const end = activeElement.selectionEnd;
                    const text = activeElement.value;
                    activeElement.value = text.substring(0, start) + placeholder + text.substring(end);
                    activeElement.selectionStart = activeElement.selectionEnd = start + placeholder.length;
                    activeElement.focus();
                    updateCharCounts();
                    updatePreview();
                }
            });
        });

        // 字符计数
        const finalDirectiveTextarea = document.getElementById('wbap-prompt-edit-final-directive');
        const systemTextarea = document.getElementById('wbap-prompt-edit-system');
        const mainTextarea = document.getElementById('wbap-prompt-edit-main');

        if (finalDirectiveTextarea) {
            finalDirectiveTextarea.addEventListener('input', () => {
                updateCharCounts();
                updatePreview();
            });
        }
        if (systemTextarea) {
            systemTextarea.addEventListener('input', () => {
                updateCharCounts();
                updatePreview();
            });
        }
        if (mainTextarea) {
            mainTextarea.addEventListener('input', () => {
                updateCharCounts();
                updatePreview();
            });
        }

        // 预览按钮
        document.getElementById('wbap-prompt-preview-btn')?.addEventListener('click', updatePreview);

        // 变量输入框变化时更新预览
        ['wbap-edit-var-sulv1', 'wbap-edit-var-sulv2', 'wbap-edit-var-sulv3', 'wbap-edit-var-sulv4'].forEach(id => {
            document.getElementById(id)?.addEventListener('input', updatePreview);
        });

    }

    // 记忆模块状态刷新（首页卡片）
    function bindMemorySection() {
        const btn = document.getElementById('wbap-memory-open-btn');
        if (btn) {
            btn.onclick = () => {
                if (WBAP.MemoryModule?.openMemoryModal) {
                    WBAP.MemoryModule.openMemoryModal();
                }
            };
        }
        const memStatus = document.getElementById('wbap-memory-status');
        if (memStatus) {
            const cfg = WBAP.CharacterManager?.getCurrentCharacterConfig?.() || WBAP.config;
            const enabled = cfg?.memoryModule?.enabled === true;
            memStatus.textContent = enabled ? '已启用' : '未启用';
            memStatus.classList.toggle('wbap-badge-success', enabled);
            memStatus.classList.add('wbap-badge');
        }
    }

    function closePromptEditor() {
        const modal = document.getElementById('wbap-prompt-editor-modal');
        if (modal) {
            modal.classList.remove('open');
            delete modal.dataset.scope;
        }
        syncMobileRootFix();
    }

    function updateCharCounts() {
        const finalDirectiveTextarea = document.getElementById('wbap-prompt-edit-final-directive');
        const systemTextarea = document.getElementById('wbap-prompt-edit-system');
        const mainTextarea = document.getElementById('wbap-prompt-edit-main');
        const finalDirectiveCount = document.getElementById('wbap-final-directive-char-count');
        const systemCount = document.getElementById('wbap-system-char-count');
        const mainCount = document.getElementById('wbap-main-char-count');

        if (finalDirectiveTextarea && finalDirectiveCount) {
            finalDirectiveCount.textContent = `${finalDirectiveTextarea.value.length} 字符`;
        }
        if (systemTextarea && systemCount) {
            systemCount.textContent = `${systemTextarea.value.length} 字符`;
        }
        if (mainTextarea && mainCount) {
            mainCount.textContent = `${mainTextarea.value.length} 字符`;
        }
    }

    function updatePreview() {
        const previewEl = document.getElementById('wbap-prompt-preview');
        if (!previewEl) return;

        const finalDirective = document.getElementById('wbap-prompt-edit-final-directive')?.value || '';
        const systemPrompt = document.getElementById('wbap-prompt-edit-system')?.value || '';
        const mainPrompt = document.getElementById('wbap-prompt-edit-main')?.value || '';
        const var1 = document.getElementById('wbap-edit-var-sulv1')?.value || '';
        const var2 = document.getElementById('wbap-edit-var-sulv2')?.value || '';
        const var3 = document.getElementById('wbap-edit-var-sulv3')?.value || '';
        const var4 = document.getElementById('wbap-edit-var-sulv4')?.value || '';

        const replacePlaceholders = (text) => text
            .replace(/{worldbook_content}/g, '[世界书内容示例...]')
            .replace(/{context}/g, '[对话上下文示例...]')
            .replace(/{user_input}/g, '[用户输入示例...]')
            .replace(/{previous_results}/g, '[一次处理结果示例...]')
            .replace(/{role_name}/g, '[角色称号示例]')
            .replace(/{role_type}/g, '[角色类型示例]')
            .replace(/{endpoint_name}/g, '[端点名称示例]')
            .replace(/{model_name}/g, '[模型名称示例]')
            .replace(/{review_round}/g, '[轮次]')
            .replace(/{sulv1}/g, var1 || '[sulv1]')
            .replace(/{sulv2}/g, var2 || '[sulv2]')
            .replace(/{sulv3}/g, var3 || '[sulv3]')
            .replace(/{sulv4}/g, var4 || '[sulv4]');

        let previewFinalDirective = replacePlaceholders(finalDirective);
        let previewSystem = replacePlaceholders(systemPrompt);
        let previewMain = replacePlaceholders(mainPrompt);

        const finalSystemPreview = (previewFinalDirective ? previewFinalDirective + '\n' : '') + previewSystem;

        previewEl.innerHTML = `<strong style="color: var(--wbap-primary);">Final System Prompt (pre-pended):</strong>\n${previewFinalDirective || '(空)'}\n\n<strong style="color: var(--wbap-primary);">System Prompt:</strong>\n${previewSystem || '(空)'}\n\n<strong style="color: var(--wbap-primary);">Main Prompt:</strong>\n${previewMain || '(空)'}`;
    }

    function savePrompt() {
        const editorModal = document.getElementById('wbap-prompt-editor-modal');
        const scope = editorModal?.dataset.scope || 'main';
        if (scope === 'cabinet') {
            saveCabinetPrompt();
            return;
        }
        if (scope === 'tiagang') {
            saveTiagangPrompt();
            return;
        }

        const index = parseInt(document.getElementById('wbap-prompt-edit-index').value);
        const name = document.getElementById('wbap-prompt-edit-name').value.trim();
        if (!name) {
            alert('模板名称不能为空。');
            return;
        }

        // 获取现有提示词以保留变量值
        const currentConfig = WBAP.CharacterManager.getCurrentCharacterConfig();
        const existingPrompts = currentConfig.prompts || [];
        const existingPrompt = index >= 0 && index < existingPrompts.length ? existingPrompts[index] : null;
        if (index >= 0 && existingPrompt?.name && existingPrompt.name !== name) {
            WBAP.PromptManager.deletePrompt(existingPrompt.name);
        }

        // 保留现有变量值，或使用编辑器中的默认值
        const existingVariables = existingPrompt?.variables || {};
        const newVariables = {
            sulv1: document.getElementById('wbap-edit-var-sulv1')?.value || existingVariables.sulv1 || '',
            sulv2: document.getElementById('wbap-edit-var-sulv2')?.value || existingVariables.sulv2 || '',
            sulv3: document.getElementById('wbap-edit-var-sulv3')?.value || existingVariables.sulv3 || '',
            sulv4: document.getElementById('wbap-edit-var-sulv4')?.value || existingVariables.sulv4 || '',
        };
        const boundEndpointIds = getPromptBindingSelection();

        const newPromptData = {
            name: name,
            version: document.getElementById('wbap-prompt-edit-version').value,
            description: document.getElementById('wbap-prompt-edit-description').value,
            finalSystemDirective: document.getElementById('wbap-prompt-edit-final-directive').value,
            systemPrompt: document.getElementById('wbap-prompt-edit-system').value,
            mainPrompt: document.getElementById('wbap-prompt-edit-main').value,
            variables: newVariables,
            boundEndpointIds: boundEndpointIds
        };

        WBAP.PromptManager.addOrUpdatePrompt(newPromptData);

        // 更新选中项
        const newPrompts = WBAP.PromptManager.getCombinedPrompts();
        const newIndex = newPrompts.findIndex(p => p.name === name);
        if (newIndex > -1) {
            currentConfig.selectedPromptIndex = newIndex;
            WBAP.saveConfig();
        }
        refreshPromptList();
        closePromptEditor();
    }

    function saveCabinetPrompt() {
        const index = parseInt(document.getElementById('wbap-prompt-edit-index').value, 10);
        const name = document.getElementById('wbap-prompt-edit-name').value.trim();
        if (!name) {
            alert('模板名称不能为空。');
            return;
        }

        const config = WBAP.CharacterManager.getCurrentCharacterConfig();
        const superCfg = ensureSuperConcurrencyConfig(config);
        const prompts = Array.isArray(superCfg.prompts) ? superCfg.prompts : [];

        const newPromptData = {
            name: name,
            version: document.getElementById('wbap-prompt-edit-version').value,
            description: document.getElementById('wbap-prompt-edit-description').value,
            finalSystemDirective: document.getElementById('wbap-prompt-edit-final-directive').value,
            systemPrompt: document.getElementById('wbap-prompt-edit-system').value,
            mainPrompt: document.getElementById('wbap-prompt-edit-main').value,
            variables: {
                sulv1: document.getElementById('wbap-edit-var-sulv1')?.value || '',
                sulv2: document.getElementById('wbap-edit-var-sulv2')?.value || '',
                sulv3: document.getElementById('wbap-edit-var-sulv3')?.value || '',
                sulv4: document.getElementById('wbap-edit-var-sulv4')?.value || ''
            }
        };

        let targetIndex = index;
        const existingByName = prompts.findIndex(p => p.name === name);
        if (index >= 0 && index < prompts.length) {
            prompts[index] = newPromptData;
            if (existingByName >= 0 && existingByName !== index) {
                prompts.splice(existingByName, 1);
                if (existingByName < index) targetIndex = index - 1;
            }
        } else if (existingByName >= 0) {
            prompts[existingByName] = newPromptData;
            targetIndex = existingByName;
        } else {
            prompts.push(newPromptData);
            targetIndex = prompts.length - 1;
        }

        superCfg.selectedPromptIndex = targetIndex;
        superCfg.prompts = prompts;
        WBAP.saveConfig();
        refreshCabinetPromptList();
        closePromptEditor();
    }

    function deleteCabinetPrompt() {
        const config = WBAP.CharacterManager.getCurrentCharacterConfig();
        const superCfg = ensureSuperConcurrencyConfig(config);
        const prompts = Array.isArray(superCfg.prompts) ? superCfg.prompts : [];
        if (prompts.length <= 1) {
            alert('至少保留一个内阁提示词预设。');
            return;
        }
        const idx = superCfg.selectedPromptIndex || 0;
        const target = prompts[idx];
        if (!confirm(`确定删除预设「${target?.name || '未命名'}」？`)) return;
        prompts.splice(idx, 1);
        superCfg.selectedPromptIndex = Math.max(0, Math.min(idx, prompts.length - 1));
        superCfg.prompts = prompts;
        WBAP.saveConfig();
        refreshCabinetPromptList();
    }

    function exportCabinetPrompt() {
        const config = WBAP.CharacterManager.getCurrentCharacterConfig();
        const superCfg = ensureSuperConcurrencyConfig(config);
        const prompts = Array.isArray(superCfg.prompts) ? superCfg.prompts : [];
        const idx = superCfg.selectedPromptIndex || 0;
        const prompt = prompts[idx];
        if (!prompt) {
            alert('没有可导出的内阁提示词。');
            return;
        }
        const safeName = (prompt.name || 'cabinet_prompt').replace(/[\\/:*?"<>|]/g, '_');
        const dataStr = JSON.stringify(prompt, null, 2);
        const blob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${safeName}.json`;
        a.click();
        URL.revokeObjectURL(url);
    }

    function importCabinetPrompt(prompt) {
        if (!prompt || typeof prompt !== 'object') {
            throw new Error('提示词内容无效。');
        }
        const parsed = {
            name: prompt.name || '导入内阁提示词',
            version: prompt.version || '',
            description: prompt.description || '',
            finalSystemDirective: prompt.finalSystemDirective || '',
            systemPrompt: prompt.systemPrompt || '',
            mainPrompt: prompt.mainPrompt || prompt.promptTemplate || ''
        };
        if (!parsed.systemPrompt && !parsed.mainPrompt) {
            throw new Error('提示词内容为空。');
        }
        parsed.variables = prompt.variables || { sulv1: '', sulv2: '', sulv3: '', sulv4: '' };

        const config = WBAP.CharacterManager.getCurrentCharacterConfig();
        const superCfg = ensureSuperConcurrencyConfig(config);
        const prompts = Array.isArray(superCfg.prompts) ? superCfg.prompts : [];
        prompts.push(parsed);
        superCfg.prompts = prompts;
        superCfg.selectedPromptIndex = prompts.length - 1;
        WBAP.saveConfig();
        refreshCabinetPromptList();
    }

    function saveTiagangPrompt() {
        const index = parseInt(document.getElementById('wbap-prompt-edit-index').value, 10);
        const name = document.getElementById('wbap-prompt-edit-name').value.trim();
        if (!name) {
            alert('\u6a21\u677f\u540d\u79f0\u4e0d\u80fd\u4e3a\u7a7a\u3002');
            return;
        }

        const config = WBAP.CharacterManager.getCurrentCharacterConfig();
        const tgCfg = ensureTiagangConfig(config);
        const prompts = Array.isArray(tgCfg.prompts) ? tgCfg.prompts : [];

        const newPromptData = {
            name: name,
            version: document.getElementById('wbap-prompt-edit-version').value,
            description: document.getElementById('wbap-prompt-edit-description').value,
            finalSystemDirective: document.getElementById('wbap-prompt-edit-final-directive').value,
            systemPrompt: document.getElementById('wbap-prompt-edit-system').value,
            mainPrompt: document.getElementById('wbap-prompt-edit-main').value,
            variables: {
                sulv1: document.getElementById('wbap-edit-var-sulv1')?.value || '',
                sulv2: document.getElementById('wbap-edit-var-sulv2')?.value || '',
                sulv3: document.getElementById('wbap-edit-var-sulv3')?.value || '',
                sulv4: document.getElementById('wbap-edit-var-sulv4')?.value || ''
            }
        };

        let targetIndex = index;
        const existingByName = prompts.findIndex(p => p.name === name);
        if (index >= 0 && index < prompts.length) {
            prompts[index] = newPromptData;
            if (existingByName >= 0 && existingByName !== index) {
                prompts.splice(existingByName, 1);
                if (existingByName < index) targetIndex = index - 1;
            }
        } else if (existingByName >= 0) {
            prompts[existingByName] = newPromptData;
            targetIndex = existingByName;
        } else {
            prompts.push(newPromptData);
            targetIndex = prompts.length - 1;
        }

        tgCfg.selectedPromptIndex = targetIndex;
        tgCfg.prompts = prompts;
        WBAP.saveConfig();
        refreshTiagangPromptList();
        closePromptEditor();
    }

    function deleteTiagangPrompt() {
        const config = WBAP.CharacterManager.getCurrentCharacterConfig();
        const tgCfg = ensureTiagangConfig(config);
        const prompts = Array.isArray(tgCfg.prompts) ? tgCfg.prompts : [];
        if (prompts.length <= 1) {
            alert('\u81f3\u5c11\u4fdd\u7559\u4e00\u4e2a\u5929\u7eb2\u63d0\u793a\u8bcd\u9884\u8bbe\u3002');
            return;
        }
        const idx = tgCfg.selectedPromptIndex || 0;
        const target = prompts[idx];
        if (!confirm(`\u786e\u5b9a\u5220\u9664\u9884\u8bbe\u300c${target?.name || '\u672a\u547d\u540d'}\u300d\u5417\uff1f`)) return;
        prompts.splice(idx, 1);
        tgCfg.selectedPromptIndex = Math.max(0, Math.min(idx, prompts.length - 1));
        tgCfg.prompts = prompts;
        WBAP.saveConfig();
        refreshTiagangPromptList();
    }

    function exportTiagangPrompt() {
        const config = WBAP.CharacterManager.getCurrentCharacterConfig();
        const tgCfg = ensureTiagangConfig(config);
        const prompts = Array.isArray(tgCfg.prompts) ? tgCfg.prompts : [];
        const idx = tgCfg.selectedPromptIndex ?? 0;
        const prompt = prompts[idx];
        if (!prompt) {
            alert('\u6ca1\u6709\u53ef\u5bfc\u51fa\u7684\u5929\u7eb2\u63d0\u793a\u8bcd\u3002');
            return;
        }
        const safeName = (prompt.name || 'tiangang_prompt').replace(/[\\/:*?\"<>|]/g, '_');
        const dataStr = JSON.stringify(prompt, null, 2);
        const blob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${safeName}.json`;
        a.click();
        URL.revokeObjectURL(url);
    }

    function importTiagangPrompt(prompt) {
        if (!prompt || typeof prompt !== 'object') {
            throw new Error('\u63d0\u793a\u8bcd\u5185\u5bb9\u65e0\u6548\u3002');
        }
        const parsed = {
            name: prompt.name || '\u5bfc\u5165\u5929\u7eb2\u63d0\u793a\u8bcd',
            version: prompt.version || '',
            description: prompt.description || '',
            finalSystemDirective: prompt.finalSystemDirective || '',
            systemPrompt: prompt.systemPrompt || '',
            mainPrompt: prompt.mainPrompt || prompt.promptTemplate || ''
        };
        if (!parsed.systemPrompt && !parsed.mainPrompt) {
            throw new Error('\u63d0\u793a\u8bcd\u5185\u5bb9\u4e3a\u7a7a\u3002');
        }
        parsed.variables = prompt.variables || { sulv1: '', sulv2: '', sulv3: '', sulv4: '' };

        const config = WBAP.CharacterManager.getCurrentCharacterConfig();
        const tgCfg = ensureTiagangConfig(config);
        const prompts = Array.isArray(tgCfg.prompts) ? tgCfg.prompts : [];
        prompts.push(parsed);
        tgCfg.prompts = prompts;
        tgCfg.selectedPromptIndex = prompts.length - 1;
        WBAP.saveConfig();
        refreshTiagangPromptList();
    }

    function exportCurrentPrompt() {
        const currentConfig = WBAP.CharacterManager.getCurrentCharacterConfig();
        const prompts = WBAP.PromptManager.getCombinedPrompts();
        const selectedPromptIndex = currentConfig.selectedPromptIndex ?? 0;
        const prompt = prompts?.[selectedPromptIndex];
        if (!prompt) {
            alert('没有可导出的提示词。');
            return;
        }
        const dataStr = JSON.stringify(prompt, null, 2);
        const blob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        const fileName = (prompt.name || 'prompt').replace(/[^a-z0-9]/gi, '_').toLowerCase();
        a.href = url;
        a.download = `${fileName}.json`;
        a.click();
        URL.revokeObjectURL(url);
    }

    // ========== Progress Panel Control ==========
    let progressTimer = null;
    let progressStartTime = 0;
    let progressTasks = new Map(); // 存储所有任务 { id: { name, status, progress, startTime, timerInterval, completed } }
    let totalTaskCount = 0; // 总任务数
    let cancelAllCallback = null; // 取消全部任务的回调
    let cancelTaskCallbacks = new Map(); // 单个任务取消回调 { taskId: callback }

    function setCancelAllCallback(callback) {
        cancelAllCallback = callback;
    }

    function setCancelTaskCallback(taskId, callback) {
        if (callback) {
            cancelTaskCallbacks.set(taskId, callback);
        } else {
            cancelTaskCallbacks.delete(taskId);
        }
    }

    function triggerCancelAll() {
        if (cancelAllCallback && typeof cancelAllCallback === 'function') {
            cancelAllCallback();
            // 更新 UI 状态
            const statusEl = document.getElementById('wbap-progress-status');
            if (statusEl) statusEl.textContent = '正在取消...';
        }
    }

    function triggerCancelTask(taskId) {
        const callback = cancelTaskCallbacks.get(taskId);
        if (callback && typeof callback === 'function') {
            callback(taskId);
            // 更新任务 UI
            updateProgressTask(taskId, '取消中...', progressTasks.get(taskId)?.progress || 0);
        }
    }

    function showProgressPanel(message = '正在处理...', taskCount = 0) {
        const panel = document.getElementById('wbap-progress-panel');
        if (!panel) return;
        bindProgressPanelEvents();

        // 重置状态
        const titleEl = document.getElementById('wbap-progress-title');
        const barEl = document.getElementById('wbap-progress-bar');
        const statusEl = document.getElementById('wbap-progress-status');
        const percentEl = document.getElementById('wbap-progress-percent');
        const timerEl = document.getElementById('wbap-progress-timer');
        const tasksEl = document.getElementById('wbap-progress-tasks');
        const taskCountEl = document.getElementById('wbap-progress-task-count');

        if (titleEl) titleEl.textContent = message;
        if (barEl) {
            barEl.style.width = '0%';
            barEl.classList.add('animated');
            barEl.classList.remove('completed'); // 重置完成状态
        }
        if (statusEl) statusEl.textContent = '准备中...';
        if (percentEl) percentEl.textContent = '0%';
        if (timerEl) timerEl.textContent = '0.000s';
        if (tasksEl) tasksEl.innerHTML = '';
        if (taskCountEl) taskCountEl.textContent = `0/${taskCount}`;

        // 清空任务列表和回调
        progressTasks.forEach(task => {
            if (task.timerInterval) clearInterval(task.timerInterval);
        });
        progressTasks.clear();
        cancelTaskCallbacks.clear();
        totalTaskCount = taskCount;

        panel.classList.add('open');

        // 启动主计时器（毫秒精度，~60fps）
        if (progressTimer) clearInterval(progressTimer);
        progressStartTime = Date.now();
        progressTimer = setInterval(() => {
            const elapsed = Date.now() - progressStartTime;
            const seconds = (elapsed / 1000).toFixed(3);
            if (timerEl) timerEl.textContent = `${seconds}s`;
        }, 16);
    }

    function updateProgressPanel(percent, statusText) {
        const bar = document.getElementById('wbap-progress-bar');
        const statusEl = document.getElementById('wbap-progress-status');
        const percentEl = document.getElementById('wbap-progress-percent');

        if (bar) {
            bar.style.width = `${Math.min(100, Math.max(0, percent))}%`;
            if (percent >= 100) {
                bar.classList.remove('animated');
                bar.classList.add('completed');
            }
        }
        if (percentEl) {
            percentEl.textContent = `${Math.round(percent)}%`;
        }
        if (statusEl && statusText) {
            statusEl.textContent = statusText;
        }
    }

    function updateTaskCount() {
        const taskCountEl = document.getElementById('wbap-progress-task-count');
        if (!taskCountEl) return;

        let completedCount = 0;
        progressTasks.forEach(task => {
            if (task.completed) completedCount++;
        });
        taskCountEl.textContent = `${completedCount}/${totalTaskCount || progressTasks.size}`;

        // 自动更新总进度条
        if (totalTaskCount > 0) {
            const overallPercent = (completedCount / totalTaskCount) * 100;
            updateProgressPanel(overallPercent, completedCount >= totalTaskCount ? '全部完成' : `已完成 ${completedCount}/${totalTaskCount}`);
        }
    }

    function addProgressTask(taskId, taskName, initialStatus = '等待中...') {
        const tasksEl = document.getElementById('wbap-progress-tasks');
        if (!tasksEl) return;

        // 创建任务卡片
        const taskCard = document.createElement('div');
        taskCard.className = 'wbap-progress-task-card';
        taskCard.id = `wbap-task-${taskId}`;
        taskCard.innerHTML = `
            <div class="wbap-task-header">
                <span class="wbap-task-name" title="${taskName}">${taskName}</span>
                <div class="wbap-task-actions">
                    <button class="wbap-task-cancel-btn" id="wbap-task-cancel-${taskId}" title="取消此任务">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                    <span class="wbap-task-timer" id="wbap-task-timer-${taskId}">0.000s</span>
                </div>
            </div>
            <div class="wbap-task-bar-container">
                <div class="wbap-task-bar" id="wbap-task-bar-${taskId}">
                    <div class="wbap-task-glow"></div>
                    <div class="wbap-task-shimmer"></div>
                </div>
            </div>
            <div class="wbap-task-footer">
                <span class="wbap-task-status" id="wbap-task-status-${taskId}">${initialStatus}</span>
                <span class="wbap-task-percent" id="wbap-task-percent-${taskId}">0%</span>
            </div>
        `;
        tasksEl.appendChild(taskCard);

        // 绑定单个任务取消按钮
        const cancelBtn = document.getElementById(`wbap-task-cancel-${taskId}`);
        if (cancelBtn) {
            cancelBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                triggerCancelTask(taskId);
            });
        }

        // 启动任务计时器（毫秒精度）
        const taskStartTime = Date.now();
        const timerInterval = setInterval(() => {
            const timerEl = document.getElementById(`wbap-task-timer-${taskId}`);
            if (timerEl) {
                const elapsed = Date.now() - taskStartTime;
                timerEl.textContent = `${(elapsed / 1000).toFixed(3)}s`;
            }
        }, 16);

        // 存储任务信息
        progressTasks.set(taskId, {
            name: taskName,
            status: initialStatus,
            progress: 0,
            startTime: taskStartTime,
            timerInterval: timerInterval,
            completed: false
        });

        // 更新任务计数
        updateTaskCount();

        // 滚动到最新任务
        tasksEl.scrollTop = tasksEl.scrollHeight;
    }

    function updateProgressTask(taskId, status, progress) {
        const task = progressTasks.get(taskId);
        if (!task) return;

        const barEl = document.getElementById(`wbap-task-bar-${taskId}`);
        const statusEl = document.getElementById(`wbap-task-status-${taskId}`);
        const percentEl = document.getElementById(`wbap-task-percent-${taskId}`);
        const cardEl = document.getElementById(`wbap-task-${taskId}`);

        if (barEl) {
            barEl.style.width = `${Math.min(100, Math.max(0, progress))}%`;
            if (progress >= 100) {
                barEl.classList.add('completed');
            }
        }
        if (statusEl && status) {
            statusEl.textContent = status;
        }
        if (percentEl) {
            percentEl.textContent = `${Math.round(progress)}%`;
        }

        // 任务完成处理
        if (cardEl && progress >= 100 && !task.completed) {
            cardEl.classList.add('completed');
            task.completed = true;
            // 停止该任务的计时器
            if (task.timerInterval) {
                clearInterval(task.timerInterval);
                task.timerInterval = null;
            }
            // 隐藏取消按钮
            const cancelBtn = document.getElementById(`wbap-task-cancel-${taskId}`);
            if (cancelBtn) cancelBtn.style.display = 'none';
            // 清理取消回调
            cancelTaskCallbacks.delete(taskId);
            // 更新任务计数
            updateTaskCount();
        }

        // 更新任务状态
        task.status = status || task.status;
        task.progress = progress;
    }

    function removeProgressTask(taskId) {
        const task = progressTasks.get(taskId);
        if (task && task.timerInterval) {
            clearInterval(task.timerInterval);
        }
        progressTasks.delete(taskId);
        cancelTaskCallbacks.delete(taskId); // 清理取消回调

        const cardEl = document.getElementById(`wbap-task-${taskId}`);
        if (cardEl) {
            cardEl.classList.add('removing');
            setTimeout(() => cardEl.remove(), 300);
        }

        // 更新任务计数
        updateTaskCount();
    }

    function hideProgressPanel() {
        const panel = document.getElementById('wbap-progress-panel');
        if (panel) {
            panel.classList.remove('open');
        }
        if (progressTimer) {
            clearInterval(progressTimer);
            progressTimer = null;
        }
        // 清理所有任务计时器
        progressTasks.forEach(task => {
            if (task.timerInterval) clearInterval(task.timerInterval);
        });
        progressTasks.clear();
        cancelTaskCallbacks.clear();
        cancelAllCallback = null;
        totalTaskCount = 0;
    }


    function makeElementDraggable(element, handle) {
        const dragHandle = handle || element;
        const margin = 8;
        let pointerId = null;
        let startX = 0;
        let startY = 0;
        let startLeft = 0;
        let startTop = 0;
        let panelWidth = 0;
        let panelHeight = 0;
        let rafId = null;
        let pending = null;

        dragHandle.style.cursor = 'move';
        dragHandle.style.touchAction = 'none';

        const applyPosition = () => {
            if (!pending) return;
            element.style.left = `${pending.left}px`;
            element.style.top = `${pending.top}px`;
            pending = null;
            rafId = null;
        };

        const onPointerDown = (e) => {
            if (pointerId !== null) return;
            if (e.button !== undefined && e.button !== 0) return;
            if (e.target.closest?.('button, input, textarea, select, a')) return;
            if (['BUTTON', 'INPUT', 'TEXTAREA', 'SELECT', 'A'].includes(e.target.tagName)) return;

            const rect = element.getBoundingClientRect();
            element.style.left = `${rect.left}px`;
            element.style.top = `${rect.top}px`;
            element.style.right = 'auto';
            element.style.bottom = 'auto';
            element.style.margin = '0';

            startX = e.clientX;
            startY = e.clientY;
            startLeft = rect.left;
            startTop = rect.top;
            panelWidth = rect.width;
            panelHeight = rect.height;
            pointerId = e.pointerId;

            element.classList.add('wbap-progress-dragging');
            dragHandle.setPointerCapture?.(pointerId);
            e.preventDefault();
        };

        const onPointerMove = (e) => {
            if (pointerId === null || e.pointerId !== pointerId) return;
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            const maxLeft = Math.max(margin, window.innerWidth - panelWidth - margin);
            const maxTop = Math.max(margin, window.innerHeight - panelHeight - margin);
            const nextLeft = Math.min(maxLeft, Math.max(margin, startLeft + dx));
            const nextTop = Math.min(maxTop, Math.max(margin, startTop + dy));

            pending = { left: nextLeft, top: nextTop };
            if (!rafId) {
                rafId = requestAnimationFrame(applyPosition);
            }
            e.preventDefault();
        };

        const onPointerUp = (e) => {
            if (pointerId === null || e.pointerId !== pointerId) return;
            pointerId = null;
            element.classList.remove('wbap-progress-dragging');
            if (rafId) {
                cancelAnimationFrame(rafId);
                rafId = null;
            }
            applyPosition();
            dragHandle.releasePointerCapture?.(e.pointerId);
        };

        dragHandle.addEventListener('pointerdown', onPointerDown);
        dragHandle.addEventListener('pointermove', onPointerMove);
        dragHandle.addEventListener('pointerup', onPointerUp);
        dragHandle.addEventListener('pointercancel', onPointerUp);
    }

    function makeElementResizable(element, handle) {
        if (!handle) return;
        const margin = 8;
        const minWidth = 280;
        const minHeight = 220;
        let pointerId = null;
        let startX = 0;
        let startY = 0;
        let startWidth = 0;
        let startHeight = 0;
        let startLeft = 0;
        let startTop = 0;
        let rafId = null;
        let pending = null;

        handle.style.touchAction = 'none';

        const applySize = () => {
            if (!pending) return;
            element.style.width = `${pending.width}px`;
            element.style.height = `${pending.height}px`;
            element.style.maxWidth = 'none';
            element.style.maxHeight = 'none';
            pending = null;
            rafId = null;
        };

        const onPointerDown = (e) => {
            if (pointerId !== null) return;
            if (e.button !== undefined && e.button !== 0) return;
            e.stopPropagation();

            const rect = element.getBoundingClientRect();
            element.style.left = `${rect.left}px`;
            element.style.top = `${rect.top}px`;
            element.style.right = 'auto';
            element.style.bottom = 'auto';
            element.style.margin = '0';

            startX = e.clientX;
            startY = e.clientY;
            startWidth = rect.width;
            startHeight = rect.height;
            startLeft = rect.left;
            startTop = rect.top;
            pointerId = e.pointerId;

            element.classList.add('wbap-progress-resizing');
            handle.setPointerCapture?.(pointerId);
            e.preventDefault();
        };

        const onPointerMove = (e) => {
            if (pointerId === null || e.pointerId !== pointerId) return;
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            const maxWidth = Math.max(minWidth, window.innerWidth - startLeft - margin);
            const maxHeight = Math.max(minHeight, window.innerHeight - startTop - margin);
            const nextWidth = Math.min(maxWidth, Math.max(minWidth, startWidth + dx));
            const nextHeight = Math.min(maxHeight, Math.max(minHeight, startHeight + dy));

            pending = { width: nextWidth, height: nextHeight };
            if (!rafId) {
                rafId = requestAnimationFrame(applySize);
            }
            e.preventDefault();
        };

        const onPointerUp = (e) => {
            if (pointerId === null || e.pointerId !== pointerId) return;
            pointerId = null;
            element.classList.remove('wbap-progress-resizing');
            if (rafId) {
                cancelAnimationFrame(rafId);
                rafId = null;
            }
            applySize();
            handle.releasePointerCapture?.(e.pointerId);
        };

        handle.addEventListener('pointerdown', onPointerDown);
        handle.addEventListener('pointermove', onPointerMove);
        handle.addEventListener('pointerup', onPointerUp);
        handle.addEventListener('pointercancel', onPointerUp);
    }

    function bindProgressPanelEvents() {
        const panel = document.getElementById('wbap-progress-panel');
        if (panel) {
            if (panel.getAttribute('data-wbap-bound') === 'true') return;
            // Make the entire panel draggable
            const dragHandle = panel.querySelector('.wbap-progress-header');
            makeElementDraggable(panel, dragHandle || panel);

            // Make resizable
            const handle = document.getElementById('wbap-progress-resize-handle');
            if (handle) {
                makeElementResizable(panel, handle);
            }

            // Close button
            const closeBtn = document.getElementById('wbap-progress-close');
            if (closeBtn) {
                closeBtn.addEventListener('click', hideProgressPanel);
            }

            // Cancel all button
            const cancelAllBtn = document.getElementById('wbap-progress-cancel-all');
            if (cancelAllBtn) {
                cancelAllBtn.addEventListener('click', triggerCancelAll);
            }

            panel.setAttribute('data-wbap-bound', 'true');
        }
    }

    // Expose functions global
    window.WBAP.UI = {
        injectUI,
        renderApiEndpoints,
        loadSettingsToUI,
        refreshPromptList,
        refreshOptimizationPromptList,
        refreshSecondaryPromptUI,
        refreshTiagangPromptList,
        showProgressPanel,
        updateProgressPanel,
        hideProgressPanel,
        addProgressTask,
        updateProgressTask,
        removeProgressTask,
        setCancelAllCallback,
        setCancelTaskCallback,
        openApiEndpointEditor: (presetValue, onSave) => {
            const modal = document.getElementById('wbap-endpoint-editor-modal');
            if (!modal) return;
            const nameInput = document.getElementById('wbap-endpoint-edit-name');
            const urlInput = document.getElementById('wbap-endpoint-edit-url');
            const keyInput = document.getElementById('wbap-endpoint-edit-key');
            const modelInput = document.getElementById('wbap-endpoint-edit-model');
            const maxTokensInput = document.getElementById('wbap-endpoint-edit-max-tokens');
            const tempInput = document.getElementById('wbap-endpoint-edit-temperature');
            if (nameInput) nameInput.value = presetValue || '';
            if (urlInput) urlInput.value = '';
            if (keyInput) keyInput.value = '';
            if (modelInput) modelInput.value = '';
            if (maxTokensInput) maxTokensInput.value = '2000';
            if (tempInput) tempInput.value = '0.7';
            modal.classList.add('open');
            syncMobileRootFix();
            const saveBtn = document.getElementById('wbap-endpoint-editor-save');
            const originalSave = saveBtn.onclick;
            saveBtn.onclick = () => {
                const endpointId = nameInput?.value?.trim() || presetValue || '';
                if (typeof onSave === 'function') onSave(endpointId);
                modal.classList.remove('open');
                syncMobileRootFix();
                saveBtn.onclick = originalSave;
            };
        }
    };
    // root alias for other modules
    window.WBAP.openApiEndpointEditor = window.WBAP.UI.openApiEndpointEditor;
    window.WBAP.syncMobileRootFix = syncMobileRootFix;

    function openCabinetPromptEditor(index) {
        const editorModal = document.getElementById('wbap-prompt-editor-modal');
        if (!editorModal) return;
        editorModal.dataset.scope = 'cabinet';
        document.getElementById('wbap-prompt-edit-index').value = index;

        const config = WBAP.CharacterManager.getCurrentCharacterConfig();
        const superCfg = ensureSuperConcurrencyConfig(config);
        const prompts = Array.isArray(superCfg.prompts) ? superCfg.prompts : [];
        const prompt = index >= 0 ? prompts[index] : null;

        if (index === -1 || !prompt) {
            document.getElementById('wbap-prompt-edit-name').value = '';
            document.getElementById('wbap-prompt-edit-version').value = '';
            document.getElementById('wbap-prompt-edit-description').value = '';
            document.getElementById('wbap-prompt-edit-final-directive').value = '';
            document.getElementById('wbap-prompt-edit-system').value = '';
            document.getElementById('wbap-prompt-edit-main').value = '';
            document.getElementById('wbap-edit-var-sulv1').value = '';
            document.getElementById('wbap-edit-var-sulv2').value = '';
            document.getElementById('wbap-edit-var-sulv3').value = '';
            document.getElementById('wbap-edit-var-sulv4').value = '';
            editorModal.querySelector('h3').textContent = '新建内阁提示词';
        } else {
            document.getElementById('wbap-prompt-edit-name').value = prompt.name || '';
            document.getElementById('wbap-prompt-edit-version').value = prompt.version || '';
            document.getElementById('wbap-prompt-edit-description').value = prompt.description || '';
            document.getElementById('wbap-prompt-edit-final-directive').value = prompt.finalSystemDirective || '';
            document.getElementById('wbap-prompt-edit-system').value = prompt.systemPrompt || '';
            document.getElementById('wbap-prompt-edit-main').value = prompt.mainPrompt || prompt.promptTemplate || '';
            const vars = prompt.variables || {};
            document.getElementById('wbap-edit-var-sulv1').value = vars.sulv1 || '';
            document.getElementById('wbap-edit-var-sulv2').value = vars.sulv2 || '';
            document.getElementById('wbap-edit-var-sulv3').value = vars.sulv3 || '';
            document.getElementById('wbap-edit-var-sulv4').value = vars.sulv4 || '';
            editorModal.querySelector('h3').textContent = '编辑内阁提示词';
        }

        updateCharCounts();
        updatePreview();
        editorModal.classList.add('open');
        syncMobileRootFix();
        setTimeout(() => {
            document.getElementById('wbap-prompt-edit-name')?.focus();
        }, 100);
    }

    function openTiagangPromptEditor(index) {
        const editorModal = document.getElementById('wbap-prompt-editor-modal');
        if (!editorModal) return;
        editorModal.dataset.scope = 'tiagang';
        document.getElementById('wbap-prompt-edit-index').value = index;

        const config = WBAP.CharacterManager.getCurrentCharacterConfig();
        const tgCfg = ensureTiagangConfig(config);
        const prompts = Array.isArray(tgCfg.prompts) ? tgCfg.prompts : [];
        const prompt = index >= 0 ? prompts[index] : null;

        if (index === -1 || !prompt) {
            document.getElementById('wbap-prompt-edit-name').value = '';
            document.getElementById('wbap-prompt-edit-version').value = '';
            document.getElementById('wbap-prompt-edit-description').value = '';
            document.getElementById('wbap-prompt-edit-final-directive').value = '';
            document.getElementById('wbap-prompt-edit-system').value = '';
            document.getElementById('wbap-prompt-edit-main').value = '';
            document.getElementById('wbap-edit-var-sulv1').value = '';
            document.getElementById('wbap-edit-var-sulv2').value = '';
            document.getElementById('wbap-edit-var-sulv3').value = '';
            document.getElementById('wbap-edit-var-sulv4').value = '';
            editorModal.querySelector('h3').textContent = '\u65b0\u5efa\u5929\u7eb2\u63d0\u793a\u8bcd';
        } else {
            document.getElementById('wbap-prompt-edit-name').value = prompt.name || '';
            document.getElementById('wbap-prompt-edit-version').value = prompt.version || '';
            document.getElementById('wbap-prompt-edit-description').value = prompt.description || '';
            document.getElementById('wbap-prompt-edit-final-directive').value = prompt.finalSystemDirective || '';
            document.getElementById('wbap-prompt-edit-system').value = prompt.systemPrompt || '';
            document.getElementById('wbap-prompt-edit-main').value = prompt.mainPrompt || prompt.promptTemplate || '';
            const vars = prompt.variables || {};
            document.getElementById('wbap-edit-var-sulv1').value = vars.sulv1 || '';
            document.getElementById('wbap-edit-var-sulv2').value = vars.sulv2 || '';
            document.getElementById('wbap-edit-var-sulv3').value = vars.sulv3 || '';
            document.getElementById('wbap-edit-var-sulv4').value = vars.sulv4 || '';
            editorModal.querySelector('h3').textContent = '\u7f16\u8f91\u5929\u7eb2\u63d0\u793a\u8bcd';
        }

        updateCharCounts();
        updatePreview();
        editorModal.classList.add('open');
        syncMobileRootFix();
        setTimeout(() => {
            document.getElementById('wbap-prompt-edit-name')?.focus();
        }, 100);
    }

    window.wbapEditPrompt = (index) => {
        const editorModal = document.getElementById('wbap-prompt-editor-modal');
        if (!editorModal) return;
        editorModal.dataset.scope = 'main';
        document.getElementById('wbap-prompt-edit-index').value = index;
        let boundIds = [];

        if (index === -1) {
            // 新建模式
            document.getElementById('wbap-prompt-edit-name').value = '';
            document.getElementById('wbap-prompt-edit-version').value = '';
            document.getElementById('wbap-prompt-edit-description').value = '';
            document.getElementById('wbap-prompt-edit-final-directive').value = '';
            document.getElementById('wbap-prompt-edit-system').value = '';
            document.getElementById('wbap-prompt-edit-main').value = '';
            document.getElementById('wbap-edit-var-sulv1').value = '';
            document.getElementById('wbap-edit-var-sulv2').value = '';
            document.getElementById('wbap-edit-var-sulv3').value = '';
            document.getElementById('wbap-edit-var-sulv4').value = '';
            editorModal.querySelector('h3').textContent = '新建提示词模板';
        } else {
            // 编辑模式
            const currentConfig = WBAP.CharacterManager.getCurrentCharacterConfig();
            const combined = WBAP.PromptManager.getCombinedPrompts();
            const selectedPrompt = combined?.[index];
            if (!selectedPrompt) return;
            const userPrompts = currentConfig.prompts || [];
            const userIndex = userPrompts.findIndex(p => p.name === selectedPrompt.name);
            const prompt = userIndex >= 0 ? userPrompts[userIndex] : selectedPrompt;
            // 使用用户提示词索引（若不存在则作为新建保存回用户列表）
            document.getElementById('wbap-prompt-edit-index').value = userIndex;
            if (!prompt) return;
            document.getElementById('wbap-prompt-edit-name').value = prompt.name || '';
            document.getElementById('wbap-prompt-edit-version').value = prompt.version || '';
            document.getElementById('wbap-prompt-edit-description').value = prompt.description || '';
            document.getElementById('wbap-prompt-edit-final-directive').value = prompt.finalSystemDirective || '';
            document.getElementById('wbap-prompt-edit-system').value = prompt.systemPrompt || '';
            document.getElementById('wbap-prompt-edit-main').value = prompt.mainPrompt || '';

            // 加载变量值（如果有）
            const vars = prompt.variables || {};
            document.getElementById('wbap-edit-var-sulv1').value = vars.sulv1 || '';
            document.getElementById('wbap-edit-var-sulv2').value = vars.sulv2 || '';
            document.getElementById('wbap-edit-var-sulv3').value = vars.sulv3 || '';
            document.getElementById('wbap-edit-var-sulv4').value = vars.sulv4 || '';
            boundIds = Array.isArray(prompt.boundEndpointIds) ? prompt.boundEndpointIds : [];

            editorModal.querySelector('h3').textContent = '编辑提示词模板';
        }

        renderPromptBindingList(boundIds);

        // 更新字符计数和预览
        updateCharCounts();
        updatePreview();

        editorModal.classList.add('open');
        syncMobileRootFix();

        // 聚焦到名称输入框
        setTimeout(() => {
            document.getElementById('wbap-prompt-edit-name')?.focus();
        }, 100);
    };
    window.wbapDeletePrompt = (index) => {
        const prompts = WBAP.PromptManager.getCombinedPrompts();
        const promptToDelete = prompts[index];
        if (!promptToDelete) return;

        if (confirm(`确定要删除提示词 "${promptToDelete.name}" 吗？`)) {
            WBAP.PromptManager.deletePrompt(promptToDelete.name);
            // After deleting, the selected index might be out of bounds.
            const currentConfig = WBAP.CharacterManager ? WBAP.CharacterManager.getCurrentCharacterConfig() : WBAP.config;
            const newPrompts = WBAP.PromptManager.getCombinedPrompts();
            if (currentConfig.selectedPromptIndex >= newPrompts.length) {
                currentConfig.selectedPromptIndex = Math.max(0, newPrompts.length - 1);
                // 同步更新全局 config
                if (WBAP.config !== currentConfig) {
                    WBAP.config.selectedPromptIndex = currentConfig.selectedPromptIndex;
                }
                WBAP.saveConfig();
            }
            refreshPromptList();
        }
    };

    window.wbapDeleteEndpoint = (id) => {
        const endpoints = WBAP.config.selectiveMode.apiEndpoints;
        const index = endpoints.findIndex(ep => ep.id === id);
        if (index > -1 && confirm('确定要删除这个API实例吗？')) {
            endpoints.splice(index, 1);
            WBAP.saveConfig();
            renderApiEndpoints();
        }
    };

    // ========== API 实例编辑辅助 ==========
    let currentEditingEndpoint = null;

    function normalizeEndpointStructure(endpoint) {
        if (!Array.isArray(endpoint.worldBooks)) {
            const wb = endpoint.worldBook || '';
            endpoint.worldBooks = wb ? [wb] : [];
        }
        if (endpoint.topP == null) endpoint.topP = 1;
        if (endpoint.presencePenalty == null) endpoint.presencePenalty = 0;
        if (endpoint.frequencyPenalty == null) endpoint.frequencyPenalty = 0;
        if (endpoint.maxRetries == null) endpoint.maxRetries = 1;
        if (endpoint.retryDelayMs == null) endpoint.retryDelayMs = 800;
        if (endpoint.enabled === undefined) {
            endpoint.enabled = true;
        }
        if (endpoint.dedupe === undefined) {
            endpoint.dedupe = true;
        }
        if (!endpoint.assignedEntriesMap) {
            endpoint.assignedEntriesMap = {};
            if (endpoint.worldBooks.length && Array.isArray(endpoint.assignedEntries)) {
                endpoint.assignedEntriesMap[endpoint.worldBooks[0]] = endpoint.assignedEntries;
            }
        }
        delete endpoint.worldBook;
        delete endpoint.assignedEntries;
    }

    function renderSelectedWorldbooks(endpoint) {
        const container = document.getElementById('wbap-endpoint-selected-worldbooks');
        if (!container) return;
        if (!endpoint.worldBooks || endpoint.worldBooks.length === 0) {
            container.innerHTML = '<small class="wbap-text-muted">尚未选择世界书</small>';
            return;
        }
        container.innerHTML = endpoint.worldBooks.map(name => `
            <span class="wbap-tag" style="background: var(--wbap-bg-secondary, #2a2a3a); padding: 4px 8px; border-radius: 12px; display: inline-flex; align-items: center; gap: 6px;">
                <span>${name}</span>
                <button type="button" data-remove-book="${name}" class="wbap-btn wbap-btn-xs wbap-btn-icon" style="padding: 0 6px;">&times;</button>
            </span>
        `).join('');
    }

    // Helpers to detect and normalize table-style worldbooks (UI layer)
    function uiIsTableWorldBook(book) {
        if (!book || !book.entries) return false;
        const entries = Object.values(book.entries).filter(e => e && e.disable !== true);
        if (entries.length === 0) return false;
        const comments = entries.map(e => e.comment || '');
        const indexCount = comments.filter(c => /Index\s+for\s+/i.test(c)).length;
        const detailPatternCount = comments.filter(c => /Detail:\s*.+?-/.test(c)).length;
        const columnCounts = {};
        comments.forEach((c, idx) => {
            const col = uiNormalizeColumnName(c, String(idx));
            columnCounts[col] = (columnCounts[col] || 0) + 1;
        });
        const repeatedColumns = Object.values(columnCounts).filter(n => n >= 2).length;
        if (indexCount >= 3) return true;
        if (detailPatternCount >= 5 && repeatedColumns >= 3) return true;
        return false;
    }

    function uiNormalizeColumnName(comment = '', fallbackId = '') {
        const trimmed = (comment || '').trim();
        const fallback = '未命名栏目';
        if (!trimmed) return fallback;
        const detailMatch = trimmed.match(/Detail:\s*([^-]+?)(\s*-\s*.*)?$/i);
        if (detailMatch) return detailMatch[1].trim() || fallback;
        const indexMatch = trimmed.match(/Index\s+for\s+(.+?)$/i);
        if (indexMatch) return indexMatch[1].trim() || fallback;
        const bracketMatch = trimmed.match(/【([^】]+)】/);
        if (bracketMatch) return bracketMatch[1].trim() || fallback;
        const parts = trimmed.split(/\s*-\s*/);
        if (parts.length > 1) return parts[0].trim() || fallback;
        return trimmed || fallbackId || fallback;
    }

    async function displayEntriesForBook(bookName, endpoint) {
        const entryList = document.getElementById('wbap-endpoint-edit-entry-list');
        if (!entryList) return;

        // Visually mark the selected book
        document.querySelectorAll('#wbap-endpoint-book-list-container .wbap-book-item').forEach(item => {
            item.classList.remove('active');
        });
        const bookItem = document.querySelector(`#wbap-endpoint-book-list-container .wbap-book-item[data-book-name="${bookName}"]`);
        if (bookItem) {
            bookItem.classList.add('active');
        }

        entryList.innerHTML = '<p class="wbap-text-muted" style="text-align: center;"><i class="fa-solid fa-spinner fa-spin"></i> 正在加载条目...</p>';

        const book = await WBAP.loadWorldBookEntriesByName(bookName);
        if (!book || !book.entries) {
            entryList.innerHTML = `<p style="color: var(--wbap-danger); text-align: center;">加载世界书 ${bookName} 失败</p>`;
            return;
        }

        const selected = new Set(endpoint.assignedEntriesMap?.[bookName] || []);
        const entries = Object.entries(book.entries).filter(([uid, entry]) => entry.disable !== true);

        if (entries.length === 0) {
            entryList.innerHTML = `<p class="wbap-text-muted" style="text-align: center; font-size: 12px;">此世界书没有启用的条目</p>`;
            return;
        }

        // Table-style worldbook: show one checkbox per column (栏目汇总)
        if (uiIsTableWorldBook(book)) {
            const selectedColumns = new Set();
            selected.forEach(id => {
                const entry = book.entries?.[id];
                if (entry) {
                    selectedColumns.add(uiNormalizeColumnName(entry.comment, id));
                }
            });
            const columnBest = new Map();
            entries.forEach(([uid, entry]) => {
                const colName = uiNormalizeColumnName(entry.comment, uid);
                const isIndex = /Index\s+for\s+/i.test(entry.comment || '');
                const len = (entry.content || '').length;
                const existing = columnBest.get(colName);
                if (!existing) {
                    columnBest.set(colName, { uid, isIndex, len });
                } else if (!existing.isIndex && isIndex) {
                    columnBest.set(colName, { uid, isIndex, len });
                } else if (existing.isIndex === isIndex && len > existing.len) {
                    columnBest.set(colName, { uid, isIndex, len });
                }
            });

            const items = Array.from(columnBest.entries()).map(([colName, info]) => {
                const uid = info.uid;
                const checked = selectedColumns.has(colName) ? 'checked' : '';
                const badge = info.isIndex ? '<span class="wbap-badge">Index</span>' : '';
                return `<label class="wbap-entry-item"><input type="checkbox" data-book="${bookName}" value="${uid}" ${checked}> ${colName} ${badge}</label>`;
            }).join('');
            entryList.innerHTML = items;
            return;
        }

        // Default: list all entries
        const items = entries.map(([uid, entry]) => {
            const title = entry.comment || `条目 ${uid.substring(0, 6)}`;
            const checked = selected.has(uid) ? 'checked' : '';
            return `<label class="wbap-entry-item"><input type="checkbox" data-book="${bookName}" value="${uid}" ${checked}> ${title}</label>`;
        }).join('');

        entryList.innerHTML = items;
    }

    // New function to render the list of worldbooks
    function renderWorldBookList(endpoint) {
        const bookListContainer = document.getElementById('wbap-endpoint-book-list-container');
        const entryListContainer = document.getElementById('wbap-endpoint-edit-entry-list');

        if (!bookListContainer || !entryListContainer) return;

        bookListContainer.innerHTML = ''; // Clear previous list
        entryListContainer.innerHTML = '<p class="wbap-text-muted" style="text-align: center; font-size: 12px;">请从左侧选择一本世界书</p>'; // Reset entry list

        if (!endpoint.worldBooks || endpoint.worldBooks.length === 0) {
            bookListContainer.innerHTML = '<p class="wbap-text-muted" style="padding: 8px; text-align: center; font-size: 12px;">请先添加世界书</p>';
            return;
        }

        endpoint.worldBooks.forEach(bookName => {
            const bookItem = document.createElement('div');
            bookItem.className = 'wbap-book-item';
            bookItem.textContent = bookName;
            bookItem.dataset.bookName = bookName;
            bookItem.addEventListener('click', () => displayEntriesForBook(bookName, endpoint));
            bookListContainer.appendChild(bookItem);
        });

        // Automatically select the first book
        if (endpoint.worldBooks.length > 0) {
            displayEntriesForBook(endpoint.worldBooks[0], endpoint);
        }
    }

    function bindEndpointEditorEvents() {
        document.getElementById('wbap-endpoint-editor-close').addEventListener('click', () => {
            document.getElementById('wbap-endpoint-editor-modal').classList.remove('open');
            syncMobileRootFix();
        });
        document.getElementById('wbap-endpoint-editor-save').addEventListener('click', saveEndpoint);

        // Test Connection button
        document.getElementById('wbap-endpoint-test-btn').addEventListener('click', async () => {
            const resultEl = document.getElementById('wbap-endpoint-test-result');
            resultEl.textContent = '测试中...';
            resultEl.style.color = 'inherit';

            const tempConfig = {
                apiUrl: document.getElementById('wbap-endpoint-edit-url').value,
                apiKey: document.getElementById('wbap-endpoint-edit-key').value,
                model: document.getElementById('wbap-endpoint-edit-model').value,
                maxTokens: parseInt(document.getElementById('wbap-endpoint-edit-max-tokens').value) || 2000,
                temperature: parseFloat(document.getElementById('wbap-endpoint-edit-temperature').value) || 0.7,
            };

            const result = await WBAP.testEndpointConnection(tempConfig);
            if (result.success) {
                resultEl.textContent = result.message;
                resultEl.style.color = 'var(--wbap-success, #28a745)';
            } else {
                resultEl.textContent = `失败: ${result.message}`;
                resultEl.style.color = 'var(--wbap-danger, #dc3545)';
            }
        });

        // Fetch Models button
        document.getElementById('wbap-endpoint-fetch-models-btn').addEventListener('click', async (e) => {
            const btn = e.currentTarget;
            btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';
            btn.disabled = true;

            const tempConfig = {
                apiUrl: document.getElementById('wbap-endpoint-edit-url').value,
                apiKey: document.getElementById('wbap-endpoint-edit-key').value,
            };

            const result = await WBAP.fetchEndpointModels(tempConfig);
            if (result.success) {
                const modelSelect = document.getElementById('wbap-endpoint-edit-model');

                if (modelSelect) {
                    const currentModel = modelSelect.value;
                    modelSelect.innerHTML = ''; // Clear existing options
                    result.models.forEach(model => {
                        const option = document.createElement('option');
                        option.value = model;
                        option.textContent = model;
                        if (model === currentModel) {
                            option.selected = true;
                        }
                        modelSelect.appendChild(option);
                    });
                    if (!modelSelect.value && result.models.length > 0) {
                        modelSelect.selectedIndex = 0;
                    }
                }
            } else {
                alert(`获取模型失败: ${result.message}`);
            }

            btn.innerHTML = '获取模型';
            btn.disabled = false;
        });

        document.getElementById('wbap-endpoint-entries-select-all')?.addEventListener('click', () => {
            const checkboxes = document.querySelectorAll('#wbap-endpoint-edit-entry-list input[type="checkbox"]');
            if (checkboxes.length === 0 || !currentEditingEndpoint) return;

            const bookName = checkboxes[0].dataset.book;
            const newIds = [];
            checkboxes.forEach(cb => {
                cb.checked = true;
                newIds.push(cb.value);
            });

            if (bookName) {
                if (!currentEditingEndpoint.assignedEntriesMap[bookName]) {
                    currentEditingEndpoint.assignedEntriesMap[bookName] = [];
                }
                // Add all new IDs to the set (handling potential duplicates if any, though map replace is safer)
                // Since we selected ALL visible entries for this book, and this list usually represents the *entire* list for this book,
                // we can just set the map to these IDs? 
                // Wait, renderWorldBookList filters entries? 
                // Step 346 shows it might filter by columns ("best version of each entry").
                // So we should probably merge with existing if the list is partial, or replace if it's full.
                // But checking line 1562 in Step 346, it iterates `columnBest.entries()`. It seems to show all unique UIDs for the book.
                // So replacing the list for this book with these IDs is correct.
                // BUT, to be safe against partial rendering (if any), let's use a Set merge.

                const currentIds = new Set(currentEditingEndpoint.assignedEntriesMap[bookName]);
                newIds.forEach(id => currentIds.add(id));
                currentEditingEndpoint.assignedEntriesMap[bookName] = Array.from(currentIds);
                Logger.log(`全选已应用: 世界书=${bookName}, 总计=${currentEditingEndpoint.assignedEntriesMap[bookName].length}条`);
            }
        });

        document.getElementById('wbap-endpoint-entries-clear')?.addEventListener('click', () => {
            const checkboxes = document.querySelectorAll('#wbap-endpoint-edit-entry-list input[type="checkbox"]');
            if (checkboxes.length === 0 || !currentEditingEndpoint) return;

            const bookName = checkboxes[0].dataset.book;
            const idsToRemove = new Set();
            checkboxes.forEach(cb => {
                cb.checked = false;
                idsToRemove.add(cb.value);
            });

            if (bookName && currentEditingEndpoint.assignedEntriesMap[bookName]) {
                currentEditingEndpoint.assignedEntriesMap[bookName] = currentEditingEndpoint.assignedEntriesMap[bookName].filter(id => !idsToRemove.has(id));
                Logger.log(`清空已应用: 世界书=${bookName}, 剩余=${currentEditingEndpoint.assignedEntriesMap[bookName].length}条`);
            }
        });

        // Temperature slider
        document.getElementById('wbap-endpoint-edit-temperature').addEventListener('input', (e) => {
            const valueEl = document.getElementById('wbap-endpoint-edit-temperature-value');
            if (valueEl) valueEl.textContent = e.target.value;
        });

        document.getElementById('wbap-endpoint-add-worldbook').addEventListener('click', () => {
            const select = document.getElementById('wbap-endpoint-edit-worldbook-select');
            if (!select || !currentEditingEndpoint) return;
            const bookName = select.value;
            if (!bookName) {
                alert('请先选择一个世界书');
                return;
            }
            if (!currentEditingEndpoint.worldBooks.includes(bookName)) {
                currentEditingEndpoint.worldBooks.push(bookName);
            }
            if (!currentEditingEndpoint.assignedEntriesMap[bookName]) {
                currentEditingEndpoint.assignedEntriesMap[bookName] = [];
            }
            renderSelectedWorldbooks(currentEditingEndpoint);
            renderWorldBookList(currentEditingEndpoint);
        });

        document.getElementById('wbap-endpoint-selected-worldbooks').addEventListener('click', (e) => {
            const btn = e.target.closest('[data-remove-book]');
            if (!btn || !currentEditingEndpoint) return;
            const bookName = btn.dataset.removeBook;
            currentEditingEndpoint.worldBooks = currentEditingEndpoint.worldBooks.filter(n => n !== bookName);
            delete currentEditingEndpoint.assignedEntriesMap[bookName];
            renderSelectedWorldbooks(currentEditingEndpoint);
            renderWorldBookList(currentEditingEndpoint);
        });

        document.getElementById('wbap-endpoint-edit-entry-list').addEventListener('change', (e) => {
            if (e.target.type === 'checkbox' && currentEditingEndpoint) {
                const bookName = e.target.dataset.book;
                const entryId = e.target.value;
                if (!bookName || !entryId) return;

                if (!currentEditingEndpoint.assignedEntriesMap[bookName]) {
                    currentEditingEndpoint.assignedEntriesMap[bookName] = [];
                }

                const selectedSet = new Set(currentEditingEndpoint.assignedEntriesMap[bookName]);
                if (e.target.checked) {
                    selectedSet.add(entryId);
                } else {
                    selectedSet.delete(entryId);
                }
                currentEditingEndpoint.assignedEntriesMap[bookName] = Array.from(selectedSet);
                Logger.log(`条目选择已更新: 世界书=${bookName}, 选中=${currentEditingEndpoint.assignedEntriesMap[bookName].length}条`);
            }
        });
    }

    window.wbapEditEndpoint = async (id) => {
        window.wbapCurrentEndpointId = id;
        const modal = document.getElementById('wbap-endpoint-editor-modal');
        if (!modal) return;

        // 确保结构存在
        if (!WBAP.config.selectiveMode) {
            WBAP.config.selectiveMode = { apiEndpoints: [] };
        }
        if (!Array.isArray(WBAP.config.selectiveMode.apiEndpoints)) {
            WBAP.config.selectiveMode.apiEndpoints = [];
        }

        let endpoint = WBAP.config.selectiveMode.apiEndpoints.find(ep => ep.id === id);
        if (!endpoint && WBAP.config.selectiveMode.apiEndpoints.length > 0) {
            // id 可能过期，回退到第一个
            endpoint = WBAP.config.selectiveMode.apiEndpoints[0];
        }
        if (!endpoint) {
            // Create default endpoint when list is empty
            endpoint = {
                id: `ep_${Date.now()}`,
                name: 'New API',
                apiUrl: '',
                apiKey: '',
                model: '',
                maxTokens: 2000,
                temperature: 0.7,
                topP: 1,
                presencePenalty: 0,
                frequencyPenalty: 0,
                maxRetries: 1,
                retryDelayMs: 800,
                timeout: WBAP.mainConfig?.globalSettings?.timeout || 60,
                enabled: true,
                dedupe: true,
                worldBooks: [],
                assignedEntriesMap: {}
            };
            WBAP.config.selectiveMode.apiEndpoints.push(endpoint);
            WBAP.saveConfig();
        }
        normalizeEndpointStructure(endpoint);
        currentEditingEndpoint = endpoint;

        // 填充基础信息
        document.getElementById('wbap-endpoint-editor-title').textContent = `编辑 API: ${endpoint.name}`;
        document.getElementById('wbap-endpoint-edit-id').value = endpoint.id;
        document.getElementById('wbap-endpoint-edit-name').value = endpoint.name;
        const enabledInput = document.getElementById('wbap-endpoint-edit-enabled');
        if (enabledInput) {
            enabledInput.checked = endpoint.enabled !== false;
        }
        const dedupeInput = document.getElementById('wbap-endpoint-edit-dedupe');
        if (dedupeInput) {
            dedupeInput.checked = endpoint.dedupe !== false;
        }
        // 兼容旧字段 url/key
        document.getElementById('wbap-endpoint-edit-url').value = endpoint.apiUrl || endpoint.url || '';
        document.getElementById('wbap-endpoint-edit-key').value = endpoint.apiKey || endpoint.key || '';
        const modelSelect = document.getElementById('wbap-endpoint-edit-model');
        modelSelect.innerHTML = ''; // 清空旧选项
        if (endpoint.model) {
            const option = document.createElement('option');
            option.value = endpoint.model;
            option.textContent = endpoint.model;
            option.selected = true;
            modelSelect.appendChild(option);
        } else {
            modelSelect.innerHTML = '<option value="" disabled selected>请先获取模型</option>';
        }
        document.getElementById('wbap-endpoint-edit-max-tokens').value = endpoint.maxTokens || 2000;
        const tempSlider = document.getElementById('wbap-endpoint-edit-temperature');
        const tempValue = document.getElementById('wbap-endpoint-edit-temperature-value');
        if (tempSlider && tempValue) {
            tempSlider.value = endpoint.temperature || 0.7;
            tempValue.textContent = endpoint.temperature || 0.7;
        }
        const topPInput = document.getElementById('wbap-endpoint-edit-top-p');
        if (topPInput) topPInput.value = endpoint.topP ?? 1;
        const presenceInput = document.getElementById('wbap-endpoint-edit-presence-penalty');
        if (presenceInput) presenceInput.value = endpoint.presencePenalty ?? 0;
        const frequencyInput = document.getElementById('wbap-endpoint-edit-frequency-penalty');
        if (frequencyInput) frequencyInput.value = endpoint.frequencyPenalty ?? 0;
        const maxRetriesInput = document.getElementById('wbap-endpoint-edit-max-retries');
        if (maxRetriesInput) maxRetriesInput.value = endpoint.maxRetries ?? 1;
        const retryDelayInput = document.getElementById('wbap-endpoint-edit-retry-delay');
        if (retryDelayInput) retryDelayInput.value = endpoint.retryDelayMs ?? 800;
        const timeoutInput = document.getElementById('wbap-endpoint-edit-timeout');
        if (timeoutInput) {
            const globalTimeout = WBAP.mainConfig?.globalSettings?.timeout || 0;
            const timeoutVal = (endpoint.timeout !== undefined && endpoint.timeout !== null)
                ? endpoint.timeout
                : (globalTimeout || 60);
            timeoutInput.value = timeoutVal;
        }

        // 填充世界书下拉列表
        const worldbookSelect = document.getElementById('wbap-endpoint-edit-worldbook-select');
        worldbookSelect.innerHTML = '<option value="">-- 请选择 --</option>';
        const bookNames = await WBAP.getAllWorldBookNames();
        bookNames.forEach(name => {
            const option = document.createElement('option');
            option.value = name;
            option.textContent = name;
            worldbookSelect.appendChild(option);
        });

        renderSelectedWorldbooks(endpoint);
        renderWorldBookList(endpoint);

        modal.classList.add('open');
        syncMobileRootFix();
    };

    function saveEndpoint() {
        const id = document.getElementById('wbap-endpoint-edit-id').value;
        const endpoint = WBAP.config.selectiveMode.apiEndpoints.find(ep => ep.id === id);
        if (!endpoint) return;

        endpoint.name = document.getElementById('wbap-endpoint-edit-name').value;
        endpoint.apiUrl = document.getElementById('wbap-endpoint-edit-url').value;
        endpoint.apiKey = document.getElementById('wbap-endpoint-edit-key').value;
        endpoint.model = document.getElementById('wbap-endpoint-edit-model').value;
        endpoint.maxTokens = parseInt(document.getElementById('wbap-endpoint-edit-max-tokens').value) || 2000;
        endpoint.temperature = parseFloat(document.getElementById('wbap-endpoint-edit-temperature').value) || 0.7;
        endpoint.topP = parseFloat(document.getElementById('wbap-endpoint-edit-top-p').value);
        if (isNaN(endpoint.topP)) endpoint.topP = 1;
        endpoint.presencePenalty = parseFloat(document.getElementById('wbap-endpoint-edit-presence-penalty').value);
        if (isNaN(endpoint.presencePenalty)) endpoint.presencePenalty = 0;
        endpoint.frequencyPenalty = parseFloat(document.getElementById('wbap-endpoint-edit-frequency-penalty').value);
        if (isNaN(endpoint.frequencyPenalty)) endpoint.frequencyPenalty = 0;
        const timeoutVal = parseInt(document.getElementById('wbap-endpoint-edit-timeout').value, 10);
        endpoint.timeout = isNaN(timeoutVal) ? 0 : timeoutVal;
        endpoint.maxRetries = parseInt(document.getElementById('wbap-endpoint-edit-max-retries').value, 10);
        if (isNaN(endpoint.maxRetries)) endpoint.maxRetries = 1;
        endpoint.retryDelayMs = parseInt(document.getElementById('wbap-endpoint-edit-retry-delay').value, 10);
        if (isNaN(endpoint.retryDelayMs)) endpoint.retryDelayMs = 800;
        endpoint.enabled = document.getElementById('wbap-endpoint-edit-enabled')?.checked !== false;
        endpoint.dedupe = document.getElementById('wbap-endpoint-edit-dedupe')?.checked !== false;

        // The assignedEntriesMap is now updated live by a 'change' listener,
        // so we just need to ensure the worldBooks array is clean.
        endpoint.worldBooks = Array.isArray(endpoint.worldBooks) ? Array.from(new Set(endpoint.worldBooks)) : [];

        // Clean up old fields to avoid confusion
        delete endpoint.url;
        delete endpoint.key;
        delete endpoint.worldBook;
        delete endpoint.assignedEntries;

        WBAP.saveConfig();
        document.getElementById('wbap-endpoint-editor-modal').classList.remove('open');
        WBAP.UI.renderApiEndpoints(); // Refresh the list in the settings view
        syncMobileRootFix();
        Logger.log(`API instance "${endpoint.name}" saved`);
    }

    // 在脚本加载后立即尝试注入UI
    // injectUI();

    window.addEventListener('resize', syncMobileRootFix);

})();
