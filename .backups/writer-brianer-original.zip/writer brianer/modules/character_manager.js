// modules/character_manager.js

(function() {
    'use strict';

    window.WBAP = window.WBAP || {};
    const Logger = WBAP.Logger;

    let currentCharacterId = null;

    function normalizeCharacterKey(id) {
        if (id === null || id === undefined) return null;
        return String(id);
    }

    // 增强的角色配置查找函数
    function findCharacterConfig(targetId) {
        const mainConfig = WBAP.mainConfig;
        if (!mainConfig?.characterConfigs) return null;

        // 1. 精确匹配
        if (mainConfig.characterConfigs[targetId]) {
            return { key: targetId, config: mainConfig.characterConfigs[targetId] };
        }

        // 2. 尝试数字/字符串转换
        const numId = Number(targetId);
        if (!isNaN(numId) && mainConfig.characterConfigs[numId]) {
            return { key: numId, config: mainConfig.characterConfigs[numId] };
        }
        const strId = String(targetId);
        if (mainConfig.characterConfigs[strId]) {
            return { key: strId, config: mainConfig.characterConfigs[strId] };
        }

        // 3. 尝试通过avatar匹配
        try {
            const context = SillyTavern.getContext();
            const avatar = context?.character?.avatar_file_name;
            if (avatar && mainConfig.characterConfigs[avatar]) {
                return { key: avatar, config: mainConfig.characterConfigs[avatar] };
            }
        } catch (e) {
            // ignore
        }

        // 4. 尝试模糊匹配（去除特殊字符）
        const normalized = String(targetId).replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
        if (normalized) {
            for (const [key, config] of Object.entries(mainConfig.characterConfigs)) {
                const keyNormalized = String(key).replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
                if (keyNormalized === normalized) {
                    return { key, config };
                }
            }
        }

        return null;
    }

    function migrateCharacterConfigKey(targetId, legacyId, legacyAvatar) {
        const key = normalizeCharacterKey(targetId);
        if (!key) return;

        const mainConfig = WBAP.mainConfig;
        if (!mainConfig?.characterConfigs) return;

        // 如果目标键已存在，不迁移
        if (mainConfig.characterConfigs[key]) return;

        // 尝试找到旧配置（使用增强的查找函数）
        const found = findCharacterConfig(legacyId) || findCharacterConfig(legacyAvatar);
        if (!found) return;

        // 迁移配置
        mainConfig.characterConfigs[key] = found.config;

        // 不立即删除旧配置，保留作为备份
        // 可以在下次启动时清理（通过版本号标记）

        if (typeof WBAP.saveConfig === 'function') {
            WBAP.saveConfig();
        }
        Logger.log(`已迁移角色配置: ${found.key} -> ${key}`);
    }

    function resolveCurrentCharacterId() {
        try {
            const context = SillyTavern.getContext();
            const character = context?.character;
            const rawId = (context && context.characterId !== undefined && context.characterId !== null)
                ? context.characterId
                : (character?.id ?? null);
            const id = normalizeCharacterKey(rawId);
            if (id) migrateCharacterConfigKey(id, character?.id, character?.avatar_file_name || null);
            return id;
        } catch (e) {
            return null;
        }
    }

    // 获取当前角色的配置
    function getCurrentCharacterConfig() {
        const mainConfig = WBAP.mainConfig;

        // 在插件完全加载前，如果被调用，返回默认配置
        if (!mainConfig) {
            Logger.warn('getCurrentCharacterConfig 在 mainConfig 初始化前被调用。');
            const createDefault = WBAP.createDefaultCharacterConfig;
            return createDefault ? createDefault() : JSON.parse(JSON.stringify(WBAP.DEFAULT_CONFIG || {}));
        }

        if (!mainConfig.characterConfigs) {
            mainConfig.characterConfigs = {};
        }

        if (!currentCharacterId) {
            currentCharacterId = resolveCurrentCharacterId();
        }

        // 使用'default'作为主页配置键，而不是临时配置
        const key = currentCharacterId || 'default';

        if (!mainConfig.characterConfigs[key]) {
            Logger.log(`为${key === 'default' ? '主页' : '角色 ' + key}创建新的默认配置。`);
            const createDefault = WBAP.createDefaultCharacterConfig;
            mainConfig.characterConfigs[key] = createDefault
                ? createDefault()
                : JSON.parse(JSON.stringify(WBAP.DEFAULT_CONFIG));

            // 立即保存新创建的配置
            if (typeof WBAP.saveConfig === 'function') {
                WBAP.saveConfig();
            }
        }

        // 始终返回当前角色的配置
        return mainConfig.characterConfigs[key];
    }

    // 切换角色时调用的函数
    function switchCharacter(characterId) {
        // 使用'default'作为主页配置键
        const key = characterId || 'default';

        // 如果角色未改变，直接返回
        if (currentCharacterId === key) return;

        Logger.log(`切换到${key === 'default' ? '主页' : '角色 ' + key}`);
        currentCharacterId = key;

        // 更新全局的活动配置对象
        window.WBAP.config = getCurrentCharacterConfig();

        // 保存当前角色到localStorage（用于恢复）
        try {
            localStorage.setItem('WBAP_current_character', key);
        } catch (e) {
            Logger.warn('无法保存当前角色到localStorage', e);
        }

        // 通知UI刷新
        if (window.WBAP.UI) {
            if (typeof window.WBAP.UI.loadSettingsToUI === 'function') {
                WBAP.UI.loadSettingsToUI();
            }
            if (typeof window.WBAP.UI.refreshPromptList === 'function') {
                WBAP.UI.refreshPromptList();
            }
            if (typeof window.WBAP.UI.renderApiEndpoints === 'function') {
                WBAP.UI.renderApiEndpoints();
            }
        }
    }

    // 初始化，监听角色加载事件
    function initialize() {
        if (typeof SillyTavern !== 'undefined' && SillyTavern.getContext) {
            const context = SillyTavern.getContext();
            let lastCharacterId = null;
            let eventListenerCount = 0;

            // 统一的切换处理函数
            const handleCharacterSwitch = () => {
                try {
                    const context = SillyTavern.getContext();
                    const rawId = (context && context.characterId !== undefined && context.characterId !== null)
                        ? context.characterId
                        : (context?.character?.id ?? null);
                    const id = normalizeCharacterKey(rawId);

                    // 只在ID真正变化时才切换
                    if (id !== lastCharacterId) {
                        Logger.log(`检测到角色变化: ${lastCharacterId || 'null'} -> ${id || 'null'}`);
                        lastCharacterId = id;

                        if (id) {
                            migrateCharacterConfigKey(id, context?.character?.id, context?.character?.avatar_file_name);
                        }

                        switchCharacter(id);
                    }
                } catch (e) {
                    Logger.error('处理角色切换时出错', e);
                }
            };

            // 方案A: CHARACTER_LOADED事件
            if (context.eventSource && context.event_types?.CHARACTER_LOADED) {
                context.eventSource.on(context.event_types.CHARACTER_LOADED, () => {
                    eventListenerCount++;
                    handleCharacterSwitch();
                });
                Logger.log('已监听CHARACTER_LOADED事件');
            }

            // 方案B: CHAT_CHANGED事件
            if (context.eventSource && context.event_types?.CHAT_CHANGED) {
                context.eventSource.on(context.event_types.CHAT_CHANGED, () => {
                    eventListenerCount++;
                    // 不使用setTimeout，立即处理
                    handleCharacterSwitch();
                });
                Logger.log('已监听CHAT_CHANGED事件');
            }

            // 方案C: 轮询（始终启用，作为兜底）
            setInterval(() => {
                // 如果事件监听正常工作，轮询不会触发切换（因为ID未变化）
                // 如果事件失效，轮询会接管
                handleCharacterSwitch();
            }, 1000); // 1秒轮询
            Logger.log('已启动角色切换轮询检测（1秒间隔）');

            // 监控事件监听器是否正常工作
            setInterval(() => {
                const count = eventListenerCount;
                eventListenerCount = 0;
                if (count === 0) {
                    Logger.warn('事件监听器可能失效，已降级到轮询模式');
                }
            }, 10000); // 每10秒检查一次

            // 初始化时立即执行一次
            handleCharacterSwitch();

        } else {
            Logger.warn('SillyTavern 上下文不可用，无法实现角色配置绑定。');
        }

        // 初始化时，立即设置一次当前角色的配置
        window.WBAP.config = getCurrentCharacterConfig();
    }

    // 暴露接口
    window.WBAP.CharacterManager = {
        initialize,
        getCurrentCharacterConfig,
        switchCharacter,
        get currentCharacterId() {
            return currentCharacterId;
        }
    };

})();
